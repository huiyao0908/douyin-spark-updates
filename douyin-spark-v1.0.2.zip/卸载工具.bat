@echo off
chcp 65001 >nul
title 抖音续火花 - 一键卸载

echo ========================================
echo    抖音自动续火花工具 - 一键卸载
echo ========================================
echo.

:: ===== 安全检查：确认当前目录是抖音续火花目录 =====
if not exist "%~dp0app.py" (
    echo [错误] 当前目录不是抖音续火花安装目录！
    echo 请将本脚本放在抖音续火花文件夹内运行。
    echo.
    pause
    exit /b 1
)
if not exist "%~dp0douyin_bot.py" (
    echo [错误] 当前目录不是抖音续火花安装目录！
    echo 缺少 douyin_bot.py 文件。
    echo.
    pause
    exit /b 1
)

echo 即将卸载以下内容：
echo   1. 停止抖音续火花服务（端口5000）
echo   2. 删除开机自启项
echo   3. 删除桌面快捷方式
echo   4. 卸载部署时安装的Python依赖包
echo   5. 卸载Playwright浏览器（如部署时安装）
echo   6. 删除防火墙规则
echo   7. 卸载内网穿透工具（cpolar/cloudflared）
echo   8. 删除当前目录下的所有程序文件
echo.
echo 注意：
echo   - Python运行环境不会自动卸载（可能是系统已有的）
echo   - 如Python是本工具安装的，可在"设置-应用"中手动卸载
echo   - 部署包zip和其他个人文件不受影响
echo.
set /p CONFIRM=确认卸载？输入 Y 继续，其他键取消: 
if /i not "%CONFIRM%"=="Y" (
    echo 已取消卸载。
    pause
    exit /b 0
)
echo.

:: ===== [1/8] 停止服务 =====
echo [1/8] 正在停止服务...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :5000 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
)
echo 服务已停止

:: ===== [2/8] 删除开机自启 =====
echo.
echo [2/8] 正在删除开机自启...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "DouyinSpark" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "抖音续火花" /f >nul 2>&1
echo 开机自启已删除

:: ===== [3/8] 删除桌面快捷方式 =====
echo.
echo [3/8] 正在删除桌面快捷方式...
del "%USERPROFILE%\Desktop\抖音续火花管理面板.url" >nul 2>&1
del "%USERPROFILE%\Desktop\启动抖音续火花.lnk" >nul 2>&1
del "%USERPROFILE%\Desktop\停止抖音续火花.lnk" >nul 2>&1
del "%USERPROFILE%\Desktop\抖音续火花.lnk" >nul 2>&1
del "%USERPROFILE%\Desktop\抖音续火花*.lnk" >nul 2>&1
echo 桌面快捷方式已删除

:: ===== [4/8] 卸载Python依赖包 =====
echo.
echo [4/8] 正在卸载Python依赖包...
python --version >nul 2>&1
if not errorlevel 1 (
    echo 检测到Python，正在卸载依赖包...
    python -m pip uninstall -y flask >nul 2>&1
    python -m pip uninstall -y playwright >nul 2>&1
    python -m pip uninstall -y apscheduler >nul 2>&1
    python -m pip uninstall -y pillow >nul 2>&1
    echo Python依赖包已卸载
) else (
    echo 未检测到Python，跳过
)

:: ===== [5/8] 卸载Playwright浏览器 =====
echo.
echo [5/8] 正在检查Playwright浏览器...
python -m playwright --version >nul 2>&1
if not errorlevel 1 (
    echo 检测到Playwright，正在卸载浏览器...
    python -m playwright uninstall --all >nul 2>&1
    echo Playwright浏览器已卸载
) else (
    echo 未检测到Playwright，跳过
)

:: ===== [6/8] 删除防火墙规则 =====
echo.
echo [6/8] 正在删除防火墙规则...
netsh advfirewall firewall delete rule name="抖音续火花管理面板" >nul 2>&1
echo 防火墙规则已删除

:: ===== [7/8] 卸载内网穿透工具 =====
echo.
echo [7/8] 正在检查内网穿透工具...

:: 检查 cpolar
where cpolar >nul 2>&1
if not errorlevel 1 (
    echo 检测到 cpolar，正在卸载...
    wmic product where "name like '%%cpolar%%'" call uninstall /nointeractive >nul 2>&1
    if exist "C:\Program Files\cpolar" rmdir /s /q "C:\Program Files\cpolar" 2>nul
    if exist "C:\Program Files (x86)\cpolar" rmdir /s /q "C:\Program Files (x86)\cpolar" 2>nul
    if exist "%USERPROFILE%\.cpolar" rmdir /s /q "%USERPROFILE%\.cpolar" 2>nul
    echo cpolar 已卸载
) else (
    echo 未检测到 cpolar
)

:: 删除 cloudflared
if exist "%~dp0cloudflared.exe" (
    echo 检测到 cloudflared，正在删除...
    del /q "%~dp0cloudflared.exe" >nul 2>&1
    echo cloudflared 已删除
)

:: ===== [8/8] 删除程序文件 =====
echo.
echo [8/8] 正在删除程序文件...
cd /d "%~dp0"

:: 删除所有子目录（包括备份、缓存等）
for /d %%d in (*) do (
    if /i not "%%d"=="." if /i not "%%d"==".." (
        rmdir /s /q "%%d" 2>nul
    )
)

:: 删除所有文件（保留卸载脚本本身，最后提示用户删除）
for %%f in (*) do (
    if /i not "%%~nxf"=="卸载工具.bat" (
        del /q "%%f" 2>nul
    )
)

echo 程序文件已删除

echo.
echo ========================================
echo    卸载完成！
echo ========================================
echo.
echo 抖音续火花工具已完全删除。
echo.
echo 如Python是本工具部署时安装的：
echo   可在 Windows 设置 -^> 应用 -^> 已安装的应用
echo   中找到 Python 3.12 并手动卸载。
echo.
echo 这个卸载脚本也可以自行删除。
echo.
pause
