@echo off
chcp 65001 >nul
title 一键黑屏
cd /d "%~dp0"

:: 动态查找pythonw
set "PYW="
for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW for %%V in (Python313 Python312 Python311 Python310 Python39) do (
    if not defined PYW if exist "%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe" set "PYW=%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe"
)

if defined PYW (
    start "" /b "%PYW%" "%~dp0黑屏工具.py"
) else (
    start "" /b pythonw "%~dp0黑屏工具.py"
)
exit
