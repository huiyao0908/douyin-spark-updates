@echo off
chcp 65001 >nul
:: 抖音续火花 - 开机自启动脚本

:: 启动抖音续火花
cd /d "%~dp0"
start "" /min "%~dp0启动服务.bat"
timeout /t 8 /nobreak >nul

:: 打开管理面板
start "" "http://127.0.0.1:5000/"
