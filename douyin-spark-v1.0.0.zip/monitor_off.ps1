﻿# 持续黑屏：使用SendMessageTimeout更可靠地关闭显示器
$ErrorActionPreference = 'SilentlyContinue'

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class MonitorCtrl {
    [DllImport("user32.dll")]
    public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out IntPtr lpdwResult);
    [DllImport("user32.dll")]
    public static extern bool BlockInput(bool fBlockIt);
}
"@

$HWND_BROADCAST = [IntPtr]0xFFFF
$WM_SYSCOMMAND = 0x0112
$SC_MONITORPOWER = 0xF170
$MONITOR_OFF = [IntPtr]2
$SMTO_ABORTIFHUNG = 0x0002

$stateFile = "$env:TEMP\monitor_blocked.txt"
"blocked" | Out-File -FilePath $stateFile -Encoding utf8

Write-Host "黑屏已启动，每3秒持续关屏，直到网页点击亮屏"

$result = [IntPtr]::Zero

while (Test-Path $stateFile) {
    [MonitorCtrl]::BlockInput($true) | Out-Null
    [MonitorCtrl]::SendMessageTimeout($HWND_BROADCAST, $WM_SYSCOMMAND, [UIntPtr]$SC_MONITORPOWER, $MONITOR_OFF, $SMTO_ABORTIFHUNG, 2000, [ref]$result) | Out-Null
    Start-Sleep -Seconds 3
}

[MonitorCtrl]::BlockInput($false) | Out-Null
Write-Host "黑屏已停止"
