﻿@echo off
chcp 65001 >nul
title 抖音续火花 - 一键部署 V1.0.5
color 0B

echo ============================================
echo    抖音自动续火花 - 一键部署 V1.0.5
echo ============================================
echo.

cd /d "%~dp0"

:: ===== [1/7] 检查/自动安装 Python =====
echo [1/7] 检查 Python 环境...
python --version >nul 2>&1
if errorlevel 1 (
    echo 未检测到 Python，正在自动下载安装...
    echo 正在下载 Python 3.12.7（约30MB）...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python_installer.exe' -UseBasicParsing"
    if errorlevel 1 (
        echo [错误] Python 下载失败！请手动安装: https://www.python.org/downloads/
        echo 安装时务必勾选 "Add Python to PATH"
        pause
        exit /b 1
    )
    echo 下载完成，正在静默安装 Python...
    "%TEMP%\python_installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_pip=1
    if errorlevel 1 (
        echo [错误] Python 安装失败！请手动运行 %TEMP%\python_installer.exe
        pause
        exit /b 1
    )
    del "%TEMP%\python_installer.exe" >nul 2>&1
    echo Python 安装完成！
    :: 刷新PATH
    for /f "tokens=2*" %%a in ('reg query "HKCU\Environment" /v PATH 2^>nul ^| findstr PATH') do set "PATH=%%b;%PATH%"
    for /f "tokens=2*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v PATH 2^>nul ^| findstr PATH') do set "PATH=%%b;%PATH%"
)
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] Python 仍不可用，请重启电脑后重新运行
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo 检测到 Python %PYVER%
echo.

:: ===== [2/7] 检查/安装 pip =====
echo [2/7] 检查 pip...
python -m pip --version >nul 2>&1
if errorlevel 1 (
    python -m ensurepip --upgrade >nul 2>&1
)
python -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple >nul 2>&1
echo pip 就绪
echo.

:: ===== [3/7] 安装 Python 依赖 =====
echo [3/7] 安装 Python 依赖包（使用国内镜像源）...
python -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
if errorlevel 1 (
    echo [警告] 国内镜像源失败，尝试默认源...
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [错误] 依赖安装失败，请检查网络连接
        pause
        exit /b 1
    )
)
echo 依赖安装完成
echo.

:: ===== [4/7] 安装 Playwright（使用系统Edge，无需下载Chromium）=====
echo [4/7] 检查浏览器...
:: 检查系统Edge
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    echo ✓ 检测到系统 Edge 浏览器
) else if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    echo ✓ 检测到系统 Edge 浏览器
) else (
    echo [提示] 未检测到 Edge 浏览器，正在下载 Playwright Chromium...
    python -m playwright install chromium
)
echo.

:: ===== [5/7] 初始化配置和目录 =====
echo [5/7] 初始化配置...
if not exist "config.json" (
    echo {"accounts":[],"browser":{"headless":false,"slow_mo":50},"schedule":{"enabled":true,"hour":0,"minute":30,"per_account":{}},"power_save":false,"live_view_enabled":true,"low_performance_mode":false,"background":""} > config.json
    echo 已创建默认配置文件
)
if not exist "storage" mkdir storage
if not exist "logs" mkdir logs
if not exist "screenshots" mkdir screenshots
echo 目录初始化完成
echo.

:: ===== [6/7] 开放防火墙端口 =====
echo [6/7] 开放防火墙端口（手机访问需要）...
netsh advfirewall firewall add rule name="抖音续火花管理面板" dir=in action=allow protocol=TCP localport=5000 >nul 2>&1
if errorlevel 1 (
    echo 需要管理员权限，正在自动请求提升...
    echo 如弹出UAC提示，请点"是"
    powershell -Command "Start-Process cmd -ArgumentList '/c netsh advfirewall firewall add rule name=\"抖音续火花管理面板\" dir=in action=allow protocol=TCP localport=5000' -Verb RunAs -Wait" >nul 2>&1
)
echo 防火墙配置完成
echo.

:: ===== [7/7] 启动服务并显示连接信息 =====
echo [7/7] 启动服务...
echo.

:: 获取局域网IP
set LAN_IP=192.168.1.100
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    set LAN_IP=%%a
    goto :got_ip
)
:got_ip
set LAN_IP=%LAN_IP: =%

echo ============================================
echo   部署完成！
echo.
echo   【电脑端】
echo   管理面板: http://127.0.0.1:5000
echo.
echo   【手机端（同一WiFi）】
echo   浏览器打开: http://%LAN_IP%:5000
echo.
echo   【手机添加到桌面（像App一样）】
echo   iPhone: Safari打开上面地址 -^> 分享 -^> 添加到主屏幕
echo   Android: Chrome打开 -^> 菜单 -^> 添加到主屏幕
echo.
echo   【外网远程控制（不在同一WiFi）】
echo   双击 "远程访问一键开启.bat"
echo   按提示操作，会生成一个外网地址
echo.
echo   日常使用：双击 "启动服务.bat"
echo   停止服务：双击 "停止服务.bat"
echo ============================================
echo.

:: 省电模式提示
echo ========================================
echo   是否开启省电模式？
echo   省电模式会：
echo   - 系统静音
echo   - 显示器10分钟自动关闭
echo   - CPU限制到70%%
echo   - 清理无用后台进程（释放内存）
echo   注意：清理进程会关闭正在运行的其他软件
echo ========================================
choice /c YN /n /m "开启省电模式？(Y/N): "
if %errorlevel%==1 (
    echo 正在开启省电模式...
    powershell -ExecutionPolicy Bypass -File "%~dp0power_save.ps1" on
) else (
    echo 已跳过省电模式
)
echo.

start "" "http://127.0.0.1:5000"
:: 用pythonw后台启动，无命令行窗口，关闭终端不影响服务
where pythonw >nul 2>&1
if %errorlevel%==0 (
    start "" /B pythonw app.py
) else (
    start "" /B python app.py
)
echo 服务已在后台启动，此窗口可以关闭。
timeout /t 3 /nobreak >nul
