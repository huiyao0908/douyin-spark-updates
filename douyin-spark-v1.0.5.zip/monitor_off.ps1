﻿# 持续黑屏：循环阻止输入+关闭显示器，直到亮屏脚本删除状态文件
$ErrorActionPreference = 'SilentlyContinue'

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class MonitorCtrl {
    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")]
    public static extern IntPtr GetDesktopWindow();
    [DllImport("user32.dll")]
    public static extern bool BlockInput(bool fBlockIt);
}
"@

$stateFile = "$env:TEMP\monitor_blocked.txt"
"blocked" | Out-File -FilePath $stateFile -Encoding utf8

Write-Host "黑屏已启动，每3秒持续关屏，直到网页点击亮屏"

while (Test-Path $stateFile) {
    [MonitorCtrl]::BlockInput($true) | Out-Null
    [MonitorCtrl]::SendMessage([MonitorCtrl]::GetDesktopWindow(), 0x0112, 0xF170, 2) | Out-Null
    Start-Sleep -Seconds 3
}

# 状态文件被删除，解除锁定
[MonitorCtrl]::BlockInput($false) | Out-Null
Write-Host "黑屏已停止"
