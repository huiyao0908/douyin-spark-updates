﻿@echo off
chcp 65001 >nul
title 抖音续火花 - 服务
cd /d "%~dp0"

set "PYW="
for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW for %%V in (Python313 Python312 Python311 Python310 Python39) do if not defined PYW if exist "%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe" set "PYW=%LOCALAPPDATA%\Programs\Python\%%V\pythonw.exe"

echo 正在启动抖音续火花服务...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0set_volume.ps1" 0 >nul 2>&1
echo 管理面板: http://127.0.0.1:5000
echo.

netstat -ano | findstr ":5000" | findstr "LISTENING" >nul
if %errorlevel%==0 (
    echo 服务已在运行，直接打开管理面板
    start "" http://127.0.0.1:5000
    timeout /t 3 >nul
    exit /b 0
)

if exist "%PYW%" (
    start "" /B "%PYW%" app.py
) else (
    echo [错误] 未找到 Python: %PYW%
    echo 请先运行 "一键部署.bat"
    pause
    exit /b 1
)

set /a N=0
:WAITLOOP
timeout /t 1 /nobreak >nul
set /a N+=1
netstat -ano | findstr ":5000" | findstr "LISTENING" >nul
if not errorlevel 1 goto OK
if %N% lss 30 goto WAITLOOP
echo.
echo 启动失败！请先运行 "一键部署.bat" 安装依赖，或检查5000端口占用。
pause
exit /b 1

:OK
echo 服务启动成功！
start "" http://127.0.0.1:5000
echo.
echo ========================================
echo   是否开启省电模式？
echo   - 系统静音 / 显示器10分钟关闭
echo   - CPU限制到70%% / 清理后台进程
echo ========================================
choice /c YN /n /m "开启省电模式？(Y/N): "
if %errorlevel%==1 (
    powershell -ExecutionPolicy Bypass -File "%~dp0power_save.ps1" on
) else (
    echo 已跳过省电模式
)
timeout /t 3 >nul