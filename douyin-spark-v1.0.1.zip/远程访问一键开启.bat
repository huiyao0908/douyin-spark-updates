@echo off
chcp 65001 >nul
title 抖音续火花 - 远程访问（国内节点）

echo ============================================
echo    抖音续火花 - 远程访问（国内节点）
echo ============================================
echo.

cd /d "%~dp0"

:: 检查服务
netstat -ano | findstr :5000 | findstr LISTENING >nul
if errorlevel 1 (
    echo [警告] 未检测到服务在运行
    echo 请先双击 启动服务.bat
    echo.
    pause
    exit /b 1
)
echo [OK] 检测到管理面板正在运行
echo.

:: 动态获取局域网IP
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    set LAN_IP=%%a
    goto got_ip
)
:got_ip
set LAN_IP=%LAN_IP: =%

:: 查找cpolar
set CPOLAR_EXE=
where cpolar >nul 2>&1
if not errorlevel 1 (
    for /f "delims=" %%i in ('where cpolar') do set CPOLAR_EXE=%%i
)
if "%CPOLAR_EXE%"=="" if exist "C:\Program Files\cpolar\cpolar.exe" set CPOLAR_EXE=C:\Program Files\cpolar\cpolar.exe
if "%CPOLAR_EXE%"=="" if exist "C:\Program Files (x86)\cpolar\cpolar.exe" set CPOLAR_EXE=C:\Program Files (x86)\cpolar\cpolar.exe

if "%CPOLAR_EXE%"=="" goto install_cpolar
goto check_token

:install_cpolar
echo [1/4] 未检测到 cpolar，正在自动下载安装...
echo.
echo 正在下载 cpolar 安装包...
powershell -Command "try { Invoke-WebRequest -Uri 'https://www.cpolar.com/static/downloads/cpolar-stable-windows-amd64.zip' -OutFile '%TEMP%\cpolar.zip' -UseBasicParsing -TimeoutSec 120; exit 0 } catch { exit 1 }"
if exist "%TEMP%\cpolar.zip" (
    echo 下载完成，正在解压安装...
    powershell -Command "Expand-Archive -Path '%TEMP%\cpolar.zip' -DestinationPath '%TEMP%\cpolar_install' -Force"
    for %%f in ("%TEMP%\cpolar_install\*.msi") do (
        echo 正在静默安装 cpolar...
        msiexec /i "%%f" /quiet /norestart
    )
    del "%TEMP%\cpolar.zip"
    rmdir /s /q "%TEMP%\cpolar_install" 2>nul
    timeout /t 3 /nobreak >nul
    set CPOLAR_EXE=
    if exist "C:\Program Files\cpolar\cpolar.exe" set CPOLAR_EXE=C:\Program Files\cpolar\cpolar.exe
    if exist "C:\Program Files (x86)\cpolar\cpolar.exe" set CPOLAR_EXE=C:\Program Files (x86)\cpolar\cpolar.exe
)
if "%CPOLAR_EXE%"=="" (
    echo [提示] 自动下载失败，正在打开下载页面...
    start https://www.cpolar.com/download
    echo.
    echo 请手动下载 Windows 版并安装
    echo 安装完成后重新运行本脚本
    echo.
    pause
    exit /b 1
)
echo [OK] cpolar 安装完成
echo.

:check_token
echo [2/4] 检查 token 配置...
set HAS_TOKEN=0
if exist "%USERPROFILE%\.cpolar\cpolar.yml" (
    findstr /i "authtoken" "%USERPROFILE%\.cpolar\cpolar.yml" >nul 2>&1
    if not errorlevel 1 set HAS_TOKEN=1
)
if "%HAS_TOKEN%"=="1" (
    echo [OK] 已配置 token
    goto start_tunnel
)

:need_token
echo [3/4] 未配置 token，正在用独立窗口打开注册页面...
:: 用Edge新窗口打开，不影响管理面板浏览器
powershell -Command "Start-Process 'msedge.exe' -ArgumentList '--new-window','https://www.cpolar.com/signup' -ErrorAction SilentlyContinue; if ($LASTEXITCODE -ne 0) { Start-Process 'https://www.cpolar.com/signup' }"
echo.
echo ============================================
echo   操作步骤：
echo   1. 在弹出的独立窗口中注册账号
echo      需要填写：用户名、邮箱、手机号、姓名
echo   2. 登录后，点左侧菜单的 验证
echo   3. 复制你的 authtoken
echo   4. 注册完成后可关闭那个浏览器窗口
echo   5. 回到本窗口粘贴 token 按回车
echo ============================================
echo.
set /p AUTHTOKEN=请粘贴 authtoken: 
if "%AUTHTOKEN%"=="" (
    echo [错误] 未输入 token
    pause
    exit /b 1
)
echo.
echo 正在配置 token...
"%CPOLAR_EXE%" authtoken %AUTHTOKEN%
if errorlevel 1 (
    echo [错误] token 配置失败，请检查 token 是否正确
    pause
    exit /b 1
)
echo [OK] token 配置成功
echo.

:start_tunnel
echo [4/4] 正在启动国内节点隧道...
echo.
echo ============================================
echo   连接方式：
echo.
echo   [同一WiFi局域网]
echo   手机打开: http://%LAN_IP%:5000
echo.
echo   [外网远程访问]
echo   查看下方 Forwarding 行
echo   会显示一个 https 开头的地址
echo   手机在任何地方打开即可控制
echo ============================================
echo.
echo 关闭此窗口即停止远程访问
echo.

:: 确保logs目录存在
if not exist "%~dp0logs" mkdir "%~dp0logs"

:: 启动cpolar，输出重定向到日志文件，同时实时显示
powershell -Command "$ErrorActionPreference='SilentlyContinue'; $p = Start-Process -FilePath '%CPOLAR_EXE%' -ArgumentList 'http','5000' -RedirectStandardOutput '%~dp0logs\cpolar.log' -RedirectStandardError '%~dp0logs\cpolar_err.log' -NoNewWindow -PassThru; Write-Host 'cpolar已启动，正在获取地址...' -ForegroundColor Green; Start-Sleep -Seconds 4; Get-Content '%~dp0logs\cpolar.log' -Wait -Tail 30"

pause
