﻿# 一键亮屏：解除BlockInput + 恢复设备 + 亮屏
$ErrorActionPreference = 'SilentlyContinue'

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class MonitorCtrl {
    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    public static extern bool BlockInput(bool fBlockIt);
    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, uint dwExtraInfo);
}
"@

# 1. 先解除键盘鼠标输入锁定（必须第一步）
[MonitorCtrl]::BlockInput($false) | Out-Null
Write-Host "已解除键盘鼠标输入锁定"

# 2. 删除状态标记
$stateFile = "$env:TEMP\monitor_blocked.txt"
if (Test-Path $stateFile) { Remove-Item $stateFile -Force }

# 3. 恢复之前保存的可唤醒设备
$saveFile = "$env:TEMP\wake_devices_backup.json"
if (Test-Path $saveFile) {
    $wakeDevices = Get-Content $saveFile -Raw | ConvertFrom-Json
    foreach ($dev in $wakeDevices) {
        powercfg /deviceenablewake $dev 2>&1 | Out-Null
    }
    Write-Host "已恢复 $($wakeDevices.Count) 个设备的唤醒权限"
    Remove-Item $saveFile -Force
}

# 4. 恢复被禁用的输入设备
$inputDevicesFile = "$env:TEMP\disabled_input_devices.json"
if (Test-Path $inputDevicesFile) {
    $inputDevices = Get-Content $inputDevicesFile -Raw | ConvertFrom-Json
    foreach ($instanceId in $inputDevices) {
        try { Enable-PnpDevice -InstanceId $instanceId -Confirm:$false -ErrorAction Stop } catch {}
    }
    Write-Host "已恢复输入设备"
    Remove-Item $inputDevicesFile -Force
}

# 5. 亮屏（MONITOR_ON + 模拟鼠标移动）
[MonitorCtrl]::SendMessage([MonitorCtrl]::GetForegroundWindow(), 0x0112, 0xF170, -1) | Out-Null
[MonitorCtrl]::mouse_event(0x0001, 1, 0, 0, 0)
[MonitorCtrl]::mouse_event(0x0001, -1, 0, 0, 0)
Write-Host "显示器已亮起"

Write-Host "`n亮屏完成！"
