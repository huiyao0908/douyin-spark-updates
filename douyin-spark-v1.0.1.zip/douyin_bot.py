"""
抖音自动续火花 - 核心浏览器操作模块
登录、发送消息、同步好友、验证登录均使用抖音网页版聊天页 (www.douyin.com/chat)
参考开源项目 DouYinSparkFlow 的实现方案
"""
import os
import re
import json
import time
import logging
from datetime import datetime
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

logger = logging.getLogger("douyin_spark")

# 全局取消发送标志
_cancel_send = False


def cancel_send():
    """设置取消发送标志，并立即关闭所有活跃浏览器页面（强制停止当前操作）"""
    global _cancel_send
    _cancel_send = True
    logger.info("用户请求取消发送，强制关闭所有活跃浏览器页面")
    # 立即关闭所有活跃bot的页面，强制中断当前操作
    for bot in list(DouyinBot._active_bots):
        try:
            if bot.keep_alive:
                # 常驻模式：关闭当前页面并新建聊天页，保留浏览器
                if bot._page:
                    try:
                        bot._page.close()
                    except Exception:
                        pass
                    bot._page = bot._context.new_page()
                    # 重新导航到聊天页，准备下次使用
                    try:
                        bot._page.goto(DOUYIN_CHAT, wait_until="domcontentloaded", timeout=30000)
                        logger.info(f"[{bot.account_name}] 常驻模式：已重新打开聊天页")
                    except Exception:
                        logger.warning(f"[{bot.account_name}] 常驻模式：重新打开聊天页失败，下次任务时会重试")
                    logger.info(f"[{bot.account_name}] 常驻模式：已取消发送并保留浏览器")
            else:
                # 非常驻模式：直接关闭浏览器
                bot._close_browser()
                logger.info(f"[{bot.account_name}] 非常驻模式：已关闭浏览器")
        except Exception as e:
            logger.debug(f"强制关闭bot失败: {e}")


def reset_cancel_send():
    """重置取消发送标志"""
    global _cancel_send
    _cancel_send = False


def is_send_cancelled():
    """检查是否已取消发送"""
    return _cancel_send


# ===== 统计追踪 =====
STATS_FILE = Path(__file__).parent / "stats.json"


def _load_stats() -> dict:
    if STATS_FILE.exists():
        try:
            with open(STATS_FILE, "r", encoding="utf-8-sig") as f:
                return json.load(f)
        except Exception:
            pass
    return {"total_success": 0, "first_run": None}


def _save_stats(stats: dict):
    try:
        with open(STATS_FILE, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"保存统计失败: {e}")


def increment_success_count(count: int = 1):
    """增加成功发送次数"""
    stats = _load_stats()
    stats["total_success"] = stats.get("total_success", 0) + count
    if not stats.get("first_run"):
        stats["first_run"] = datetime.now().isoformat()
    _save_stats(stats)


def format_spark_message(base_message: str) -> str:
    """
    格式化续火花消息：
    第一行：当前时间
    第二行：用户消息
    第三行：已成功次数 + 运行时长
    """
    stats = _load_stats()
    total = stats.get("total_success", 0)
    first_run = stats.get("first_run")

    duration_str = "刚刚开始"
    if first_run:
        try:
            start = datetime.fromisoformat(first_run)
            delta = datetime.now() - start
            days = delta.days
            hours = delta.seconds // 3600
            minutes = (delta.seconds % 3600) // 60
            if days > 0:
                duration_str = f"{days}天{hours}小时"
            elif hours > 0:
                duration_str = f"{hours}小时{minutes}分钟"
            else:
                duration_str = f"{minutes}分钟"
        except Exception:
            pass

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return f"{now_str}\n{base_message}\n已成功续火花{total}次 | 已运行{duration_str}"


BASE_DIR = Path(__file__).parent
STORAGE_DIR = BASE_DIR / "storage"
SCREENSHOT_DIR = BASE_DIR / "screenshots"
STORAGE_DIR.mkdir(exist_ok=True)
SCREENSHOT_DIR.mkdir(exist_ok=True)

# 抖音网页版聊天页（用于登录、发送消息、同步好友、查看火花天数、验证登录）
DOUYIN_CHAT = "https://www.douyin.com/chat"

# 未登录时页面会出现的关键字
LOGIN_MARKERS = ["扫码登录", "验证码登录", "密码登录"]

# www.douyin.com/chat 页面选择器（参考 DouYinSparkFlow）
CONVERSATION_ITEM_SELECTOR = ".conversationConversationItemwrapper"
CONVERSATION_TITLE_SELECTOR = ".conversationConversationItemtitle"
CONVERSATION_LIST_SELECTOR = ".conversationConversationListwrapper"
CHAT_EDITOR_SELECTOR = ".messageEditorimChatEditorContainer"
SEARCH_INPUT_SELECTOR = 'input[placeholder="搜索"]'
SEARCH_PANEL_ITEM_SELECTOR = ".SearchPanelitembox"
SEARCH_PANEL_TITLE_SELECTOR = ".SearchPanelitemtitle"
SEARCH_PANEL_CHAT_BTN_SELECTOR = ".SearchPanelitemchat_btn"


class DouyinBot:
    """抖音机器人：管理单个账号的登录和消息发送"""

    LOGIN_COOKIE_KEYWORDS = {"sessionid", "sid_guard", "sessionid_ss", "sid_tt"}

    # 全局活跃bot列表，用于取消时立即关闭浏览器
    _active_bots = []

    def __init__(self, account_name: str, browser_config: dict = None):
        self.account_name = account_name
        self.storage_file = STORAGE_DIR / f"{account_name}.json"
        self.browser_config = browser_config or {}
        self.headless = self.browser_config.get("headless", False)
        self.slow_mo = self.browser_config.get("slow_mo", 200)
        self.timeout = self.browser_config.get("timeout", 60000)
        self._playwright = None
        self._browser = None
        self._context = None
        self._page = None
        self.keep_alive = False  # 常驻模式：不自动关闭浏览器
        self.login_expired = False  # 登录失效标志（打开聊天页时检测）
        self._screenshot_cache = None  # 实时画面截图缓存（bytes），Playwright线程写，Flask线程读

    def _update_screenshot_cache(self):
        """在Playwright线程中调用，用page.screenshot()更新实时画面缓存"""
        try:
            if self._page and not self._page.is_closed():
                self._screenshot_cache = self._page.screenshot(type="jpeg", quality=70, full_page=False)
        except Exception as e:
            logger.debug(f"截图缓存更新失败: {e}")

    def _screenshot(self, tag: str):
        try:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = SCREENSHOT_DIR / f"{self.account_name}_{tag}_{ts}.png"
            if self._page:
                self._page.screenshot(path=str(path))
                logger.debug(f"截图已保存: {path.name}")
        except Exception as e:
            logger.warning(f"截图失败: {e}")

    STEALTH_JS = """
    Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
    Object.defineProperty(navigator, 'plugins', {get: () => [1,2,3,4,5]});
    Object.defineProperty(navigator, 'languages', {get: () => ['zh-CN','zh','en']});
    window.chrome = {runtime: {}};
    """

    def _start_browser(self, use_storage=True):
        """启动浏览器（全屏1920x1080，使用系统Edge）。常驻模式下复用已有浏览器（同线程）。"""
        import threading
        current_tid = threading.get_ident()

        # 常驻模式：如果浏览器已存在、连接正常、且在同一线程，直接复用
        if (self.keep_alive 
            and self._browser is not None 
            and self._browser.is_connected()
            and getattr(self, '_browser_thread_id', None) == current_tid):
            logger.info(f"[{self.account_name}] 复用已有浏览器（常驻模式，同线程）")
            # 确保page存在
            if self._page is None or self._page.is_closed():
                self._page = self._context.new_page()
            # 恢复最小化的窗口
            try:
                self._page.bring_to_front()
            except Exception:
                pass
            try:
                client = self._page.context.new_cdp_session(self._page)
                win_info = client.send("Browser.getWindowForTarget", {"targetId": self._page.target.id})
                client.send("Browser.setWindowBounds", {
                    "windowId": win_info["windowId"],
                    "bounds": {"windowState": "normal"}
                })
            except Exception:
                pass
            # 注册到活跃bot列表（复用路径也需要，否则实时画面不显示）
            if self not in DouyinBot._active_bots:
                DouyinBot._active_bots.append(self)
            # 最小化其他窗口，只显示浏览器
            self._minimize_others()
            return

        # 非常驻模式、浏览器不存在、或跨线程了，先清理旧的
        if self._browser is not None:
            try:
                self._browser.close()
            except Exception:
                pass
            self._browser = None
            self._context = None
            self._page = None

        self._playwright = sync_playwright().start()
        self._browser_thread_id = current_tid

        launch_kwargs = {
            "headless": self.headless,
            "slow_mo": self.slow_mo,
            "args": [
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--start-maximized",
                "--disable-save-password-bubble",
                "--disable-features=PasswordManager,PasswordImport,ExternalProtocolDialog,ProtocolHandler,ProtocolHandlerRegistry,WebHID,WebUSB,Serial,NotificationTriggers",
                "--disable-password-manager-reauth",
                "--disable-notifications",
                "--disable-geolocation",
                "--disable-protocol-handler",
                "--no-default-browser-check",
                "--disable-popup-blocking",
                "--disable-external-protocol-dialog",
                "--disable-web-hid",
                "--disable-webusb",
                "--disable-serial",
            ],
        }

        # 自动检测系统 Edge 浏览器（支持多个常见路径）
        edge_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]
        edge_path = None
        for p in edge_paths:
            if os.path.exists(p):
                edge_path = p
                break
        if edge_path:
            launch_kwargs["executable_path"] = edge_path
            logger.info(f"[{self.account_name}] 使用系统 Edge: {edge_path}")
        else:
            logger.info(f"[{self.account_name}] 未找到系统 Edge，使用 Playwright 内置 Chromium")

        self._browser = self._playwright.chromium.launch(**launch_kwargs)

        context_kwargs = {
            "no_viewport": True,  # 配合 --start-maximized 实现真正全屏
            "user_agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0"
            ),
            "locale": "zh-CN",
            "timezone_id": "Asia/Shanghai",
        }
        if use_storage and self.storage_file.exists():
            context_kwargs["storage_state"] = str(self.storage_file)
            logger.info(f"[{self.account_name}] 加载登录状态: {self.storage_file.name}")

        self._context = self._browser.new_context(**context_kwargs)
        self._context.add_init_script(self.STEALTH_JS)
        self._context.set_default_timeout(self.timeout)

        # 注入JS：覆盖所有可能触发权限弹窗的API
        self._context.add_init_script("""() => {
            // 覆盖协议处理器
            if (navigator.registerProtocolHandler) {
                navigator.registerProtocolHandler = () => {};
            }
            if (navigator.unregisterProtocolHandler) {
                navigator.unregisterProtocolHandler = () => {};
            }
            // 覆盖通知
            if (window.Notification) {
                window.Notification.requestPermission = () => Promise.resolve('denied');
            }
            // 覆盖地理位置
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition = () => {};
                navigator.geolocation.watchPosition = () => 0;
            }
            // 覆盖WebHID/WebUSB/Serial
            if (navigator.hid) navigator.hid.requestDevice = () => Promise.resolve([]);
            if (navigator.usb) navigator.usb.requestDevice = () => Promise.resolve(null);
            if (navigator.serial) navigator.serial.requestPort = () => Promise.resolve(null);
            // 覆盖剪贴板权限
            if (navigator.clipboard) {
                navigator.clipboard.readText = () => Promise.resolve('');
                navigator.clipboard.writeText = () => Promise.resolve();
            }
            // 覆盖权限查询
            if (navigator.permissions && navigator.permissions.query) {
                const origQuery = navigator.permissions.query.bind(navigator.permissions);
                navigator.permissions.query = (p) => origQuery(p).then(r => { r.state = 'denied'; return r; }).catch(() => ({state: 'denied'}));
            }
            // 阻止window.open触发的外部协议弹窗
            const origOpen = window.open;
            window.open = function(url, name, specs) {
                if (url && !url.startsWith('http') && !url.startsWith('about:') && !url.startsWith('blob:')) {
                    return null;
                }
                return origOpen.call(this, url, name, specs);
            };
        }""")

        # 自动处理所有弹窗（权限请求、确认框等）
        self._context.on("dialog", lambda dialog: dialog.dismiss())

        self._page = self._context.new_page()

        # 记录浏览器进程ID，用于窗口截图
        try:
            self._browser_pid = self._browser.process.pid
        except Exception:
            self._browser_pid = None

        # 激活浏览器窗口到前台
        try:
            self._page.bring_to_front()
        except Exception:
            pass

        # 用CDP预拒绝所有权限
        try:
            cdp = self._context.new_cdp_session(self._page)
            cdp.send("Browser.setPermission", {
                "permission": {"name": "notifications"},
                "setting": "denied",
            })
        except Exception:
            pass

        # 页面加载后自动拒绝权限请求、关闭弹窗
        self._page.add_locator_handler(
            self._page.locator("button:has-text('阻止'), button:has-text('拒绝'), button:has-text('取消'), button:has-text('不允许')"),
            lambda el: el.click()
        )

        # 注册到活跃bot列表（用于取消时立即关闭）
        if self not in DouyinBot._active_bots:
            DouyinBot._active_bots.append(self)

        # 最小化其他窗口，只显示浏览器（方便实时画面查看）
        self._minimize_others()

    def _minimize_others(self):
        """最小化所有其他窗口，只显示当前浏览器"""
        try:
            import subprocess
            subprocess.run(
                ['powershell', '-Command', '(New-Object -ComObject Shell.Application).MinimizeAll()'],
                capture_output=True, timeout=5
            )
            time.sleep(0.3)
            # 把浏览器窗口提到最前
            try:
                if self._page:
                    self._page.bring_to_front()
            except Exception:
                pass
            self._did_minimize = True
            logger.debug(f"[{self.account_name}] 已最小化其他窗口")
        except Exception as e:
            logger.warning(f"[{self.account_name}] 最小化窗口失败: {e}")
            self._did_minimize = False

    def _restore_others(self):
        """恢复之前最小化的窗口"""
        if not getattr(self, '_did_minimize', False):
            return
        try:
            import subprocess
            subprocess.run(
                ['powershell', '-Command', '(New-Object -ComObject Shell.Application).UndoMinimizeAll()'],
                capture_output=True, timeout=5
            )
            logger.debug(f"[{self.account_name}] 已恢复其他窗口")
        except Exception as e:
            logger.warning(f"[{self.account_name}] 恢复窗口失败: {e}")
        self._did_minimize = False

    def task_complete(self):
        """任务完成时调用：切回管理面板，从活跃列表移除"""
        # 从活跃列表移除
        if self in DouyinBot._active_bots:
            try:
                DouyinBot._active_bots.remove(self)
            except ValueError:
                pass
        try:
            import ctypes
            from ctypes import wintypes
            import time
            user32 = ctypes.windll.user32
            WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

            # 第一步：常驻模式下最小化Playwright浏览器（按标题匹配，含子进程窗口）
            if self.keep_alive:
                def minimize_chat(hwnd, _):
                    if user32.IsWindowVisible(hwnd):
                        length = user32.GetWindowTextLengthW(hwnd)
                        if length > 0:
                            buf = ctypes.create_unicode_buffer(length + 1)
                            user32.GetWindowTextW(hwnd, buf, length + 1)
                            title = buf.value
                            # Playwright浏览器标题包含douyin.com/chat，排除管理面板
                            if "douyin.com/chat" in title and "抖音自动续火花" not in title:
                                user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
                    return True
                user32.EnumWindows(WNDENUMPROC(minimize_chat), 0)
            time.sleep(0.5)

            # 第二步：找到管理面板窗口并激活
            target_hwnd = None
            def find_panel(hwnd, _):
                nonlocal target_hwnd
                if user32.IsWindowVisible(hwnd):
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buf = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buf, length + 1)
                        if "抖音自动续火花" in buf.value:
                            target_hwnd = hwnd
                            return False
                return True
            user32.EnumWindows(WNDENUMPROC(find_panel), 0)

            if target_hwnd:
                # 用Alt键技巧绕过Windows前台窗口限制
                user32.keybd_event(0x12, 0, 0, 0)  # Alt down
                time.sleep(0.05)
                user32.ShowWindow(target_hwnd, 3)  # SW_SHOWMAXIMIZED（保持最大化）
                user32.SetForegroundWindow(target_hwnd)
                time.sleep(0.05)
                user32.keybd_event(0x12, 0, 2, 0)  # Alt up
                logger.info(f"[{self.account_name}] 已切回管理面板")
            else:
                logger.info(f"[{self.account_name}] 未找到管理面板窗口")
        except Exception as e:
            logger.debug(f"切回管理面板失败: {e}")
        if not self.keep_alive:
            self._restore_others()

        # 任务完成后清理本次产生的截图
        try:
            shot_dir = Path(__file__).parent / "screenshots"
            if shot_dir.exists():
                for f in shot_dir.glob("*.png"):
                    try:
                        f.unlink()
                    except Exception:
                        pass
        except Exception:
            pass

    def _close_browser(self):
        # 恢复其他窗口
        self._restore_others()
        # 从活跃列表移除
        if self in DouyinBot._active_bots:
            try:
                DouyinBot._active_bots.remove(self)
            except ValueError:
                pass
        try:
            if self._context:
                self._context.close()
            if self._browser:
                self._browser.close()
            if self._playwright:
                self._playwright.stop()
        except Exception:
            pass
        finally:
            self._playwright = None
            self._browser = None
            self._context = None
            self._page = None

    def _save_verify_timestamp(self):
        """保存最后验证时间戳到存储文件"""
        try:
            if self.storage_file.exists():
                with open(self.storage_file, "r", encoding="utf-8-sig") as f:
                    data = json.load(f)
                data["last_verified"] = time.time()
                with open(self.storage_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False)
        except Exception as e:
            logger.debug(f"保存验证时间戳失败: {e}")

    def _check_cookies_logged_in(self) -> bool:
        """检查当前浏览器上下文中是否有有效登录cookie"""
        if not self._context:
            return False
        try:
            cookies = self._context.cookies()
            for c in cookies:
                if c["name"] in self.LOGIN_COOKIE_KEYWORDS and c.get("value"):
                    return True
            return False
        except Exception:
            return False

    def is_logged_in(self) -> bool:
        """检查本地保存的登录状态文件是否包含有效且未过期的cookie"""
        if not self.storage_file.exists():
            return False
        try:
            with open(self.storage_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            cookies = data.get("cookies", [])
            now = time.time()
            has_valid = False
            for c in cookies:
                if c["name"] in self.LOGIN_COOKIE_KEYWORDS and c.get("value"):
                    expires = c.get("expires", -1)
                    if expires == -1 or expires is None:
                        has_valid = True
                    elif expires > now:
                        has_valid = True
                    else:
                        logger.info(f"[{self.account_name}] cookie {c['name']} 已过期")
            return has_valid
        except Exception:
            return False

    # ===== 登录（抖音聊天页） =====

    def login(self, timeout: int = 300) -> dict:
        """打开抖音聊天页，等待用户扫码登录，保存状态"""
        result = {"success": False, "message": ""}
        try:
            self._start_browser(use_storage=False)
            self._page.goto(DOUYIN_CHAT, wait_until="domcontentloaded", timeout=30000)
            logger.info(f"[{self.account_name}] 请在弹出的浏览器中扫码登录抖音...")

            # 等待登录成功：用shadow DOM遍历检测（body.inner_text对shadow DOM无效）
            deadline = time.time() + timeout
            logged_in = False
            last_save = 0
            while time.time() < deadline:
                try:
                    # 用shadow DOM遍历获取完整文字
                    body_text = self._page.evaluate("""() => {
                        let text = '';
                        function walk(node) {
                            if (node.nodeType === 3) text += node.textContent + ' ';
                            if (node.nodeType === 1) {
                                if (node.shadowRoot) node.shadowRoot.childNodes.forEach(walk);
                                node.childNodes.forEach(walk);
                            }
                        }
                        walk(document);
                        return text;
                    }""")
                    has_login_marker = any(m in body_text for m in LOGIN_MARKERS)
                    # 检测会话列表（多种选择器兜底）
                    has_conversation = False
                    for sel in [CONVERSATION_LIST_SELECTOR, ".conversationConversationItemwrapper", "[class*='conversation']"]:
                        try:
                            if self._page.locator(sel).count() > 0:
                                has_conversation = True
                                break
                        except Exception:
                            pass
                    # 也可以通过URL判断：登录后chat页面不再重定向到登录页
                    url_ok = "douyin.com/chat" in self._page.url and "login" not in self._page.url
                    if (not has_login_marker and has_conversation) or (url_ok and has_conversation):
                        logged_in = True
                        break
                except Exception:
                    pass
                # 每30秒保存一次状态（防止检测失败但用户已登录）
                if time.time() - last_save > 30:
                    try:
                        self._context.storage_state(path=str(self.storage_file))
                        last_save = time.time()
                        logger.debug(f"[{self.account_name}] 登录中定期保存状态")
                    except Exception:
                        pass
                time.sleep(2)

            # 无论是否检测到登录，都保存一次状态（用户可能已登录但检测失败）
            try:
                self._context.storage_state(path=str(self.storage_file))
                logger.info(f"[{self.account_name}] 登录状态已保存到 {self.storage_file.name}")
            except Exception as e:
                logger.warning(f"[{self.account_name}] 保存状态失败: {e}")

            if not logged_in:
                # 即使没检测到，也检查一下保存的状态是否有效
                if self.is_logged_in():
                    logged_in = True
                    logger.info(f"[{self.account_name}] 检测超时但保存的状态有效，视为登录成功")
                else:
                    result["message"] = "登录超时，请重新操作"
                    self._screenshot("login_timeout")
                    return result

            logger.info(f"[{self.account_name}] 登录成功")
            time.sleep(3)  # 等待用户信息渲染
            username = self._get_chat_username()
            if username:
                result["username"] = username
                logger.info(f"[{self.account_name}] 获取到用户名: {username}")

            self._screenshot("login_success")
            result["success"] = True
            result["message"] = "登录成功"
            return result
        except Exception as e:
            result["message"] = f"登录异常: {e}"
            logger.error(f"[{self.account_name}] 登录异常: {e}")
            self._screenshot("login_error")
            return result
        finally:
            self._close_browser()

    def _get_chat_username(self) -> str:
        """从抖音聊天页获取当前用户名"""
        try:
            js = """
            () => {
                // 方式1: 从页面全局变量获取
                try {
                    const keys = Object.keys(window).filter(k => k.includes('INITIAL') || k.includes('STATE') || k.includes('USER') || k.includes('user'));
                    for (const k of keys) {
                        try {
                            const v = window[k];
                            if (v && typeof v === 'object') {
                                const s = JSON.stringify(v);
                                const m = s.match(/"nickname"\\s*:\\s*"([^"]{1,20})"/);
                                if (m) return m[1];
                                const m2 = s.match(/"nick_name"\\s*:\\s*"([^"]{1,20})"/);
                                if (m2) return m2[1];
                            }
                        } catch(e) {}
                    }
                } catch(e) {}

                // 方式2: 查找用户信息区域（左侧边栏底部通常有头像+昵称）
                // 优先找包含avatar的父元素附近的文本
                const avatarSelectors = ['img[class*="avatar"]', 'img[class*="Avatar"]', '[class*="user-avatar"]', '[class*="UserAvatar"]', '[class*="avatar"]'];
                for (const sel of avatarSelectors) {
                    const imgs = document.querySelectorAll(sel);
                    for (const img of imgs) {
                        // 向上找3层，找相邻的文本元素
                        let parent = img.parentElement;
                        for (let lvl = 0; lvl < 4 && parent; lvl++) {
                            const texts = parent.querySelectorAll('span, div, p, a');
                            for (const t of texts) {
                                const txt = t.textContent.trim();
                                if (txt && txt.length >= 2 && txt.length <= 20 && t.children.length === 0 &&
                                    !txt.includes('抖音') && !txt.includes('消息') && !txt.includes('搜索') &&
                                    !txt.includes('登录') && !txt.includes('设置') && !/^\\d+$/.test(txt) &&
                                    !/^\\d{1,2}:\\d{2}$/.test(txt) && txt !== '昨天' && txt !== '今天' && txt !== '前天') {
                                    return txt;
                                }
                            }
                            parent = parent.parentElement;
                        }
                    }
                }

                // 方式3: 查找class包含nick/name/user的元素
                const nameElements = document.querySelectorAll('[class*="nick"], [class*="Nick"], [class*="user-name"], [class*="UserName"], [class*="username"]');
                for (const el of nameElements) {
                    const txt = el.textContent.trim();
                    if (txt && txt.length >= 2 && txt.length <= 20 && !txt.includes('抖音')) {
                        return txt;
                    }
                }

                // 方式4: document.title
                const title = document.title;
                if (title) {
                    if (title.includes('-')) {
                        const name = title.split('-')[0].trim();
                        if (name && name.length >= 2 && name.length <= 20 && name !== '消息' && name !== '抖音') return name;
                    }
                }

                return null;
            }
            """
            name = self._page.evaluate(js)
            if name:
                return name.strip()
        except Exception as e:
            logger.debug(f"获取用户名失败: {e}")
        return ""

    # ===== 验证登录 =====

    def verify_login(self) -> dict:
        """实际打开抖音聊天页验证登录是否有效"""
        result = {"valid": False, "message": "", "screenshot": ""}
        try:
            self._start_browser(use_storage=True)

            # 常驻模式：如果已在聊天页且会话列表正常，跳过导航
            if self.keep_alive and self._page and not self._page.is_closed():
                try:
                    current_url = self._page.url
                    if "douyin.com/chat" in current_url:
                        item_count = self._page.locator(CONVERSATION_ITEM_SELECTOR).count()
                        if item_count > 0:
                            logger.info(f"[{self.account_name}] 常驻模式：已在聊天页，跳过导航直接验证")
                            result["valid"] = True
                            result["message"] = "登录状态有效（常驻模式快速验证）"
                            return result
                except Exception:
                    pass

            self._page.goto(DOUYIN_CHAT, wait_until="domcontentloaded", timeout=30000)

            current_url = self._page.url
            logger.info(f"[{self.account_name}] 验证登录，当前URL: {current_url}")

            # 检查是否被重定向到登录页
            if "login" in current_url.lower() or "passport" in current_url.lower():
                result["message"] = "被重定向到登录页，登录已失效"
                self._screenshot("login_expired")
                result["screenshot"] = "login_expired"
                return result

            # 快速轮询：每500ms检查一次，最多等8秒
            # 一旦发现登录入口（失效）或会话列表（有效）立即返回
            conversation_loaded = False
            for wait_round in range(16):  # 16 * 0.5s = 8s
                time.sleep(0.5)
                try:
                    # 优先检查会话项（正向信号）
                    item_count = self._page.locator(CONVERSATION_ITEM_SELECTOR).count()
                    if item_count > 0:
                        result["valid"] = True
                        result["message"] = f"登录状态有效（{item_count}个会话）"
                        logger.info(f"[{self.account_name}] 验证登录通过，{item_count}个会话（第{wait_round+1}次轮询）")
                        self._save_verify_timestamp()
                        self._screenshot("login_valid")
                        return result
                    # 检查登录入口（负向信号）
                    body_text = self._page.locator("body").inner_text(timeout=2000)
                    if any(m in body_text for m in LOGIN_MARKERS):
                        result["message"] = "页面显示登录入口，登录已失效"
                        self._screenshot("login_expired")
                        result["screenshot"] = "login_expired"
                        return result
                    # 检查会话容器是否出现
                    if not conversation_loaded:
                        conv_count = self._page.locator(CONVERSATION_LIST_SELECTOR).count()
                        if conv_count > 0:
                            conversation_loaded = True
                except Exception:
                    continue

            # 8秒后仍无明确结果
            if conversation_loaded:
                result["valid"] = True
                result["message"] = "登录状态有效（会话容器已加载）"
                logger.info(f"[{self.account_name}] 验证登录通过（容器检测）")
                self._save_verify_timestamp()
                return result

            result["message"] = "未检测到会话列表，登录可能已失效"
            self._screenshot("login_unknown")
            result["screenshot"] = "login_unknown"
            return result
        except Exception as e:
            result["message"] = f"验证登录时出错: {e}"
            logger.error(f"[{self.account_name}] 验证登录异常: {e}")
            return result
        finally:
            if not self.keep_alive:
                self._close_browser()
            else:
                self.task_complete()

    # ===== 打开聊天页 =====

    def _open_chat_page(self) -> bool:
        """导航到抖音网页版聊天页 www.douyin.com/chat，确保页面完全加载。常驻模式下已在聊天页则跳过导航。"""
        # 常驻模式：如果已经在聊天页且页面正常，直接复用
        if self.keep_alive and self._page and not self._page.is_closed():
            try:
                current_url = self._page.url
                if "douyin.com/chat" in current_url:
                    # 检查会话列表是否存在
                    try:
                        self._page.wait_for_selector(CONVERSATION_LIST_SELECTOR, timeout=5000)
                        logger.info(f"[{self.account_name}] 已在聊天页且会话列表正常，跳过导航（常驻模式）")
                        time.sleep(1)
                        return True
                    except Exception:
                        logger.info(f"[{self.account_name}] 已在聊天页但会话列表未加载，重新导航")
            except Exception:
                pass

        try:
            self._page.goto(DOUYIN_CHAT, wait_until="domcontentloaded", timeout=45000)
            current_url = self._page.url
            if "login" in current_url.lower() or "passport" in current_url.lower():
                logger.warning(f"[{self.account_name}] 聊天页重定向到登录页，登录已失效")
                self.login_expired = True
                return False

            # 快速轮询：每500ms检查一次，最多等12秒
            self.login_expired = False
            for wait_round in range(24):  # 24 * 0.5s = 12s
                time.sleep(0.5)
                try:
                    # 检查登录入口（负向信号）
                    body_text = self._page.locator("body").inner_text(timeout=2000)
                    if any(m in body_text for m in LOGIN_MARKERS):
                        logger.warning(f"[{self.account_name}] 页面显示登录入口，登录已失效")
                        self.login_expired = True
                        self._screenshot("login_expired")
                        return False
                    # 检查会话项（正向信号）
                    item_count = self._page.locator(CONVERSATION_ITEM_SELECTOR).count()
                    if item_count > 0:
                        logger.info(f"[{self.account_name}] 已打开聊天页，{item_count}个会话（第{wait_round+1}次轮询）")
                        self._screenshot("chat_page")
                        self._update_screenshot_cache()
                        return True
                except Exception:
                    continue

            # 12秒后仍无会话项，检查是否有会话容器
            try:
                conv_count = self._page.locator(CONVERSATION_LIST_SELECTOR).count()
                if conv_count > 0:
                    logger.info(f"[{self.account_name}] 会话容器已加载，继续操作")
                    self._screenshot("chat_page")
                    self._update_screenshot_cache()
                    return True
            except Exception:
                pass

            logger.warning(f"[{self.account_name}] 未能加载会话列表")
            self._screenshot("chat_page_timeout")
            return False
        except Exception as e:
            logger.error(f"[{self.account_name}] 打开聊天页失败: {e}")
            self._screenshot("chat_page_error")
            return False

    # ===== 同步好友 =====

    def _scrape_friends_from_list(self) -> list:
        """从 www.douyin.com/chat 会话列表滚动抓取所有好友昵称（含火花天数）"""
        friends = []
        seen = set()

        try:
            # 等待会话标题解析完成（从数字ID变为昵称）
            for _ in range(15):
                try:
                    visible = self._page.locator(CONVERSATION_ITEM_SELECTOR).all()[:15]
                    titles = []
                    for el in visible:
                        try:
                            titles.append(el.locator(CONVERSATION_TITLE_SELECTOR).inner_text())
                        except Exception:
                            pass
                    if not titles:
                        break
                    numeric = sum(1 for t in titles if t.strip().isdigit())
                    if numeric == 0 or numeric <= max(1, len(titles) * 0.3):
                        break
                except Exception:
                    break
                time.sleep(2)

            # 先滚动到顶部（避免之前操作导致的位置偏移，漏抓上面的好友）
            try:
                scroll_el = self._page.locator(CONVERSATION_LIST_SELECTOR).first
                if scroll_el.count() > 0:
                    scroll_el.evaluate("el => el.scrollTop = 0")
                    time.sleep(0.5)
                    logger.info(f"[{self.account_name}] 会话列表已滚动到顶部")
            except Exception:
                pass

            empty_scrolls = 0
            max_empty = 8

            for scroll_round in range(30):
                try:
                    elements = self._page.locator(CONVERSATION_ITEM_SELECTOR).all()
                    for el in elements:
                        try:
                            name = el.locator(CONVERSATION_TITLE_SELECTOR).inner_text().strip()
                            if name and len(name) <= 30 and name not in seen:
                                skip_words = ['系统通知', '抖音小助手', '安全中心', '陌生人消息',
                                              '登录', '首页', '全部', 'DJI大疆']
                                if any(w in name for w in skip_words):
                                    continue
                                if re.match(r'^\d{1,2}:\d{2}$', name):
                                    continue
                                if name in ['昨天', '前天', '今天'] or name.startswith('星期'):
                                    continue
                                if len(name) <= 1:
                                    continue
                                # 尝试获取火花天数（结构化JS提取，排除时间戳误匹配）
                                spark_days = self._extract_spark_days(el)
                                seen.add(name)
                                friend = {"name": name}
                                if spark_days:
                                    friend["spark_days"] = spark_days
                                friends.append(friend)
                        except Exception:
                            continue
                except Exception:
                    pass

                # 滚动加载更多
                try:
                    scroll_el = self._page.locator(CONVERSATION_LIST_SELECTOR).first
                    if scroll_el.count() > 0:
                        before = scroll_el.evaluate("el => el.scrollTop")
                        scroll_el.evaluate("el => el.scrollTop += 800")
                        time.sleep(0.5)
                        after = scroll_el.evaluate("el => el.scrollTop")
                        if before == after:
                            empty_scrolls += 1
                            if empty_scrolls >= max_empty:
                                break
                        else:
                            empty_scrolls = 0
                    else:
                        self._page.keyboard.press("PageDown")
                        time.sleep(0.8)
                        empty_scrolls += 1
                        if empty_scrolls >= max_empty:
                            break
                except Exception:
                    empty_scrolls += 1
                    if empty_scrolls >= max_empty:
                        break

            logger.info(f"[{self.account_name}] 从会话列表抓取到 {len(friends)} 个好友")
            return friends
        except Exception as e:
            logger.error(f"[{self.account_name}] 抓取好友列表异常: {e}")
            return friends

    def _update_spark_days_for_friends(self, configured_friends: list) -> list:
        """发送完成后，从当前聊天页抓取会话列表，更新好友的火花天数
        返回更新后的好友列表（只更新spark_days，不改变其他字段）
        """
        if not self._page or self._page.is_closed():
            return []
        try:
            # 确保在聊天页
            if "douyin.com/chat" not in self._page.url:
                self._page.goto(DOUYIN_CHAT, wait_until="domcontentloaded", timeout=15000)
                self._page.wait_for_timeout(2000)
            # 滚动到顶部
            try:
                self._page.evaluate("document.querySelector('.conversationConversationListwrapper')?.scrollTo(0, 0)")
            except Exception:
                pass
            self._page.wait_for_timeout(1000)
            # 抓取会话列表（含火花天数，完整滚动）
            scraped = self._scrape_friends_from_list()
            if not scraped:
                logger.warning(f"[{self.account_name}] 刷新火花：未抓取到任何好友")
                return []
            # 建立名称到spark_days的映射（去除空格统一匹配）
            spark_map = {}
            for f in scraped:
                name = f.get("name", "").strip()
                days = f.get("spark_days")
                if name and days:
                    spark_map[name] = days
            logger.info(f"[{self.account_name}] 刷新火花：抓取到 {len(scraped)} 个好友，其中 {len(spark_map)} 个有火花天数")
            # 更新配置中的好友
            updated = []
            for f in configured_friends:
                name = f.get("name", "").strip()
                if name in spark_map:
                    f["spark_days"] = spark_map[name]
                    updated.append(f)
            # 保存到config
            try:
                import json
                from pathlib import Path
                config_path = Path(__file__).parent / "config.json"
                with open(config_path, "r", encoding="utf-8-sig") as fp:
                    cfg = json.load(fp)
                for acc in cfg.get("accounts", []):
                    if acc.get("name") == self.account_name:
                        for i, existing in enumerate(acc.get("friends", [])):
                            ename = existing.get("name", "").strip()
                            if ename in spark_map:
                                acc["friends"][i]["spark_days"] = spark_map[ename]
                        break
                with open(config_path, "w", encoding="utf-8") as fp:
                    json.dump(cfg, fp, ensure_ascii=False, indent=2)
                logger.info(f"[{self.account_name}] 火花天数已保存到config，更新了 {len(updated)} 个好友")
            except Exception as e:
                logger.warning(f"[{self.account_name}] 保存火花天数到config失败: {e}")
            return updated
        except Exception as e:
            logger.warning(f"[{self.account_name}] 更新火花天数异常: {e}")
            return []

    def get_friends_list(self, status_callback=None, keep_open_on_error=False) -> dict:
        """同步好友列表（从 www.douyin.com/chat）"""
        result = {"success": False, "friends": [], "error": "", "screenshot": ""}

        def report(step, msg):
            if status_callback:
                status_callback(step, msg)
            logger.info(f"[{self.account_name}] {step}: {msg}")

        if not self.is_logged_in():
            result["error"] = "未登录，请先登录"
            return result

        try:
            self._start_browser(use_storage=True)
            report("opening", "正在打开抖音聊天页...")

            if not self._open_chat_page():
                if self.login_expired:
                    result["error"] = "登录已失效，请重新扫码登录"
                else:
                    result["error"] = "无法打开聊天页，请检查网络或稍后重试"
                self._screenshot("no_chat_page")
                result["screenshot"] = "no_chat_page"
                return result

            report("scraping", "正在滚动抓取好友列表...")
            friends = self._scrape_friends_from_list()

            # 如果第一次抓到0个，可能页面还没加载完，等3秒重试一次
            if len(friends) == 0:
                logger.info(f"[{self.account_name}] 第一次抓取0个好友，等待3秒后重试")
                report("scraping", "页面加载较慢，等待重试...")
                time.sleep(3)
                friends = self._scrape_friends_from_list()
                if len(friends) == 0:
                    # 再等5秒最后试一次
                    logger.info(f"[{self.account_name}] 第二次仍0个，等待5秒最后重试")
                    time.sleep(5)
                    friends = self._scrape_friends_from_list()

            result["friends"] = friends
            result["success"] = True
            self._screenshot("friends_list")
            result["screenshot"] = "friends_list"

            if friends:
                report("done", f"抓取完成，共找到 {len(friends)} 个好友")
            else:
                report("done", "未抓取到好友（可能列表为空或页面结构变化）")

            return result
        except Exception as e:
            result["error"] = f"抓取异常: {e}"
            report("error", result["error"])
            self._screenshot("sync_error")
            result["screenshot"] = "sync_error"
            return result
        finally:
            if not self.keep_alive and not keep_open_on_error:
                self._close_browser()
            elif self.keep_alive:
                self.task_complete()

    # ===== 搜索好友 =====

    def _search_and_open_chat(self, nickname: str) -> bool:
        """在搜索框输入昵称，点击搜索结果打开会话"""
        try:
            if is_send_cancelled():
                return False
            search_input = self._page.locator(SEARCH_INPUT_SELECTOR)
            if search_input.count() == 0:
                return False
            search_input.fill("")
            time.sleep(0.3)
            if is_send_cancelled():
                return False
            search_input.fill(nickname)
            time.sleep(2)
            if is_send_cancelled():
                return False

            items = self._page.locator(SEARCH_PANEL_ITEM_SELECTOR)
            n = items.count()
            if n == 0:
                logger.warning(f"[{self.account_name}] 搜索「{nickname}」无结果")
                search_input.fill("")
                return False

            def norm(s):
                return re.sub(r'[^\u4e00-\u9fff\w]', '', s).lower()

            target_norm = norm(nickname.strip())
            for i in range(min(n, 10)):
                try:
                    title = items.nth(i).locator(SEARCH_PANEL_TITLE_SELECTOR).inner_text(timeout=2000).strip()
                    if norm(title) == target_norm or (target_norm and (target_norm in norm(title) or norm(title) in target_norm)):
                        # 点击"发消息"按钮
                        chat_btn = items.nth(i).locator(SEARCH_PANEL_CHAT_BTN_SELECTOR)
                        if chat_btn.count() > 0:
                            chat_btn.click()
                        else:
                            items.nth(i).click()
                        time.sleep(2)
                        logger.info(f"[{self.account_name}] 搜索打开会话「{nickname}」")
                        return True
                except Exception:
                    continue

            # 没有精确匹配，点第一个结果
            try:
                items.first.click()
                time.sleep(2)
                return True
            except Exception:
                pass

            search_input.fill("")
            return False
        except Exception as e:
            logger.warning(f"[{self.account_name}] 搜索「{nickname}」出错: {e}")
            return False

    # ===== 发送消息 =====

    def _find_and_click_friend(self, friend_name: str) -> bool:
        """查找并点击好友：优先搜索，失败则滚动列表"""
        logger.info(f"[{self.account_name}] 查找好友: {friend_name}")

        # 优先用搜索（稳定快速）
        if self._search_and_open_chat(friend_name):
            return True

        # 回退：滚动列表查找
        def norm(s):
            return re.sub(r'[^\u4e00-\u9fff\w]', '', s).lower()

        target_norm = norm(friend_name.strip())

        try:
            # 滚回顶部
            try:
                scroll_el = self._page.locator(CONVERSATION_LIST_SELECTOR).first
                if scroll_el.count() > 0:
                    scroll_el.evaluate("el => el.scrollTop = 0")
                    time.sleep(0.5)
            except Exception:
                pass

            for _ in range(25):
                if is_send_cancelled():
                    logger.info(f"[{self.account_name}] 查找好友已取消")
                    return False
                try:
                    elements = self._page.locator(CONVERSATION_ITEM_SELECTOR).all()
                    for el in elements:
                        try:
                            name = el.locator(CONVERSATION_TITLE_SELECTOR).inner_text().strip()
                            if not name:
                                continue
                            if name == friend_name or norm(name) == target_norm or \
                               (target_norm and norm(name) and (target_norm in norm(name) or norm(name) in target_norm)):
                                el.click()
                                time.sleep(1.5)
                                logger.info(f"[{self.account_name}] 列表找到并点击: {name}")
                                return True
                        except Exception:
                            continue
                except Exception:
                    pass

                try:
                    scroll_el = self._page.locator(CONVERSATION_LIST_SELECTOR).first
                    if scroll_el.count() > 0:
                        before = scroll_el.evaluate("el => el.scrollTop")
                        scroll_el.evaluate("el => el.scrollTop += 800")
                        time.sleep(0.5)
                        after = scroll_el.evaluate("el => el.scrollTop")
                        if before == after:
                            break
                    else:
                        break
                except Exception:
                    break

            logger.warning(f"[{self.account_name}] 未找到好友: {friend_name}")
            self._screenshot("friend_not_found")
            return False
        except Exception as e:
            logger.error(f"[{self.account_name}] 查找好友异常: {e}")
            self._screenshot("find_friend_error")
            return False

    def _send_message_in_chat(self, message: str) -> bool:
        """在当前聊天窗口中发送消息（www.douyin.com/chat 输入框）"""
        try:
            input_selectors = [
                CHAT_EDITOR_SELECTOR,
                'div[contenteditable="true"]',
                'textarea[placeholder*="发送"]',
                'textarea',
            ]

            input_box = None
            for sel in input_selectors:
                try:
                    loc = self._page.locator(sel).filter(visible=True).first
                    if loc.count() > 0:
                        input_box = loc
                        logger.info(f"[{self.account_name}] 找到输入框: {sel}")
                        break
                except Exception:
                    continue

            if input_box is None:
                logger.error(f"[{self.account_name}] 未找到消息输入框")
                self._screenshot("no_input_box")
                return False

            input_box.click()
            time.sleep(0.5)

            # 逐行输入，换行用 Shift+Enter
            lines = message.split("\n")
            for i, line in enumerate(lines):
                input_box.type(line)
                if i < len(lines) - 1:
                    input_box.press("Shift+Enter")
            time.sleep(0.8)

            # 按 Enter 发送前检查取消
            if is_send_cancelled():
                logger.info(f"[{self.account_name}] 发送已取消，跳过本条消息")
                return False

            # 按 Enter 发送
            input_box.press("Enter")
            time.sleep(2)

            self._screenshot("message_sent")
            logger.info(f"[{self.account_name}] 消息已发送: {message[:30]}")
            return True
        except Exception as e:
            logger.error(f"[{self.account_name}] 发送消息异常: {e}")
            self._screenshot("send_error")
            return False

    def send_to_friend(self, friend_name: str, message: str, remark: str = "") -> dict:
        """给单个好友发送消息"""
        result = {
            "success": False, "friend": friend_name, "message": message,
            "error": "", "timestamp": datetime.now().isoformat(),
        }

        if not self.is_logged_in():
            result["error"] = "未登录，请先登录"
            return result

        try:
            self._start_browser(use_storage=True)

            if not self._open_chat_page():
                result["error"] = "登录已失效，请重新扫码登录" if self.login_expired else "无法打开聊天页，请检查网络"
                return result

            search_name = remark or friend_name
            if not self._find_and_click_friend(search_name):
                result["error"] = f"未找到好友: {search_name}"
                return result

            if not self._send_message_in_chat(message):
                result["error"] = "发送消息失败"
                return result

            result["success"] = True
            return result
        except Exception as e:
            result["error"] = f"发送异常: {e}"
            logger.error(f"[{self.account_name}] 发送异常: {e}")
            return result
        finally:
            if not self.keep_alive:
                self._close_browser()
            else:
                self.task_complete()

    def send_to_all(self, friends: list, message: str) -> dict:
        """
        给多个好友发送消息（打开一次浏览器，搜索+依次发送）
        返回: {"success": bool, "results": [...], "summary": str}
        """
        results = []
        success_count = 0
        fail_count = 0
        # 注意：不要在这里 reset_cancel_send()，否则调度器循环中每个新账号都会清除取消标志
        # 取消标志由 scheduler.execute_all() 开始时统一重置

        if not friends:
            return {"success": True, "results": [], "summary": "没有好友"}

        if not self.is_logged_in():
            return {"success": False, "results": [], "summary": "未登录"}

        try:
            self._start_browser(use_storage=True)

            if not self._open_chat_page():
                msg = "登录已失效，请重新扫码登录" if self.login_expired else "无法打开聊天页"
                return {"success": False, "results": [], "summary": msg}

            # 注入悬浮取消按钮
            try:
                self._page.evaluate("""() => {
                    if (document.getElementById('spark-cancel-btn')) return;
                    const btn = document.createElement('div');
                    btn.id = 'spark-cancel-btn';
                    btn.textContent = '⏹ 取消发送';
                    btn.style.cssText = 'position:fixed;top:20px;right:20px;z-index:999999;background:linear-gradient(135deg,#ff3b30,#ff6b6b);color:#fff;padding:12px 24px;border-radius:24px;font-size:15px;font-weight:600;cursor:pointer;box-shadow:0 4px 16px rgba(255,59,48,0.4);user-select:none;transition:all 0.2s;';
                    btn.onmouseover = () => btn.style.transform = 'scale(1.05)';
                    btn.onmouseout = () => btn.style.transform = 'scale(1)';
                    btn.onclick = () => {
                        btn.textContent = '取消中...';
                        btn.style.background = 'linear-gradient(135deg,#8e8e93,#aeaeb2)';
                        fetch('http://127.0.0.1:5000/api/send/cancel', {method:'POST'})
                            .then(() => { btn.textContent = '✓ 已取消'; })
                            .catch(() => { btn.textContent = '取消失败'; });
                    };
                    document.body.appendChild(btn);
                }""")
                logger.info(f"[{self.account_name}] 已注入悬浮取消按钮")
            except Exception as e:
                logger.debug(f"注入取消按钮失败: {e}")

            if is_send_cancelled():
                return {"success": False, "results": [], "summary": "已取消"}

            # 构建目标列表
            targets = []
            for friend in friends:
                name = friend.get("name", "") if isinstance(friend, dict) else str(friend)
                remark = friend.get("remark", "") if isinstance(friend, dict) else ""
                search_name = remark or name
                if search_name:
                    targets.append({"name": name, "search_name": search_name})

            for idx, target in enumerate(targets):
                if is_send_cancelled():
                    logger.info(f"[{self.account_name}] 发送已取消，停止")
                    r = {"success": False, "friend": target["name"], "message": message,
                         "error": "已取消", "timestamp": datetime.now().isoformat()}
                    results.append(r)
                    fail_count += 1
                    continue

                name = target["name"]
                logger.info(f"[{self.account_name}] 发送第 {idx+1}/{len(targets)} 个: {name}")
                self._update_screenshot_cache()  # 更新实时画面
                r = {
                    "success": False, "friend": name, "message": message,
                    "error": "", "timestamp": datetime.now().isoformat(),
                }

                try:
                    if self._find_and_click_friend(target["search_name"]):
                        self._update_screenshot_cache()  # 更新实时画面（找到好友后）
                        formatted_msg = format_spark_message(message)
                        if self._send_message_in_chat(formatted_msg):
                            r["success"] = True
                            success_count += 1
                            increment_success_count(1)
                            logger.info(f"[{self.account_name}] 发送成功: {name}")
                            self._update_screenshot_cache()  # 更新实时画面（发送后）
                        else:
                            r["error"] = "发送消息失败"
                            fail_count += 1
                    else:
                        if is_send_cancelled():
                            r["error"] = "已取消"
                        else:
                            r["error"] = f"未找到好友: {target['search_name']}"
                        fail_count += 1
                except Exception as e:
                    r["error"] = str(e)
                    fail_count += 1
                    logger.error(f"[{self.account_name}] 发送异常 {name}: {e}")

                results.append(r)

                if idx < len(targets) - 1 and not is_send_cancelled():
                    time.sleep(1)

            cancelled = is_send_cancelled()
            summary = f"成功 {success_count} 个，失败 {fail_count} 个"
            if cancelled:
                summary += "（已取消）"
            return {
                "success": fail_count == 0 and not cancelled,
                "results": results,
                "summary": summary,
            }
        except Exception as e:
            logger.error(f"[{self.account_name}] 批量发送异常: {e}")
            return {"success": False, "results": results, "summary": f"异常: {e}"}
        finally:
            # 移除悬浮取消按钮
            try:
                if self._page and not self._page.is_closed():
                    self._page.evaluate("""() => {
                        const btn = document.getElementById('spark-cancel-btn');
                        if (btn) btn.remove();
                    }""")
            except Exception:
                pass
            if not self.keep_alive:
                self._close_browser()
            else:
                self.task_complete()  # 常驻模式：恢复窗口但不关闭浏览器
            # 注意：不要在这里 reset_cancel_send()，否则调度器循环中下一个账号会继续发送
            # 取消标志由 scheduler.execute_all() 开始时统一重置

    def _extract_spark_days(self, element) -> int:
        """从会话列表项中提取火花天数
        抖音聊天页结构：.commonStreakstreakContainer > .commonStreakicon(IMG) + .commonStreaknormalText(数字)
        """
        try:
            info = element.evaluate("""el => {
                const result = {sparkDays: null, method: ''};

                // 方法1（最可靠）：直接查找 .commonStreaknormalText 元素
                const streakText = el.querySelector('.commonStreaknormalText');
                if (streakText) {
                    const txt = (streakText.innerText || streakText.textContent || '').trim();
                    const m = txt.match(/(\\d+)/);
                    if (m) {
                        result.sparkDays = parseInt(m[1]);
                        result.method = 'streakText';
                        return result;
                    }
                }

                // 方法2：查找 .commonStreakstreakContainer 容器的文本
                const streakContainer = el.querySelector('.commonStreakstreakContainer');
                if (streakContainer) {
                    const txt = (streakContainer.innerText || streakContainer.textContent || '').trim();
                    const m = txt.match(/(\\d+)/);
                    if (m) {
                        result.sparkDays = parseInt(m[1]);
                        result.method = 'streakContainer';
                        return result;
                    }
                }

                // 方法3：查找 .commonStreakicon 图片（火焰图标），取其兄弟节点数字
                const streakIcon = el.querySelector('.commonStreakicon');
                if (streakIcon) {
                    let sibling = streakIcon.nextElementSibling;
                    while (sibling) {
                        const st = (sibling.innerText || sibling.textContent || '').trim();
                        const sm = st.match(/(\\d+)/);
                        if (sm) {
                            result.sparkDays = parseInt(sm[1]);
                            result.method = 'streakIcon_sibling';
                            return result;
                        }
                        sibling = sibling.nextElementSibling;
                    }
                    // 父元素内的数字
                    const parentText = streakIcon.parentElement?.textContent || '';
                    const pm = parentText.match(/(\\d+)/);
                    if (pm) {
                        result.sparkDays = parseInt(pm[1]);
                        result.method = 'streakIcon_parent';
                        return result;
                    }
                }

                // 方法4：兜底 - 🔥 emoji
                const allText = el.innerText || '';
                const fireMatch = allText.match(/🔥\\s*(\\d+)/);
                if (fireMatch) {
                    result.sparkDays = parseInt(fireMatch[1]);
                    result.method = 'fire_emoji';
                    return result;
                }

                return result;
            }""")
            days = info.get("sparkDays")
            if days and days > 0 and days < 10000:
                return days
        except Exception:
            pass
        return None

    def get_spark_days(self, friend_name: str, remark: str = "") -> dict:
        """获取火花天数（www.douyin.com/chat 会话列表显示火花天数）"""
        result = {
            "friend": friend_name, "spark_days": None,
            "has_spark": False, "raw_text": "",
        }
        if not self.is_logged_in():
            return result
        try:
            self._start_browser(use_storage=True)
            if not self._open_chat_page():
                result["raw_text"] = "登录已失效" if self.login_expired else "无法打开聊天页"
                return result

            # 在会话列表中查找好友及其火花天数
            def norm(s):
                return re.sub(r'[^\u4e00-\u9fff\w]', '', s).lower()
            target_norm = norm((remark or friend_name).strip())

            for _ in range(15):
                try:
                    elements = self._page.locator(CONVERSATION_ITEM_SELECTOR).all()
                    for el in elements:
                        try:
                            name = el.locator(CONVERSATION_TITLE_SELECTOR).inner_text().strip()
                            if name and (name == (remark or friend_name) or norm(name) == target_norm or
                                         (target_norm and norm(name) and target_norm in norm(name))):
                                text = el.inner_text()
                                result["raw_text"] = text[:100]
                                # 使用结构化提取方法
                                days = self._extract_spark_days(el)
                                if days:
                                    result["spark_days"] = days
                                    result["has_spark"] = True
                                self._screenshot(f"spark_{friend_name}")
                                return result
                        except Exception:
                            continue
                except Exception:
                    pass

                try:
                    scroll_el = self._page.locator(CONVERSATION_LIST_SELECTOR).first
                    if scroll_el.count() > 0:
                        before = scroll_el.evaluate("el => el.scrollTop")
                        scroll_el.evaluate("el => el.scrollTop += 800")
                        time.sleep(0.4)
                        after = scroll_el.evaluate("el => el.scrollTop")
                        if before == after:
                            break
                    else:
                        break
                except Exception:
                    break

            return result
        except Exception as e:
            logger.error(f"[{self.account_name}] 获取火花天数异常: {e}")
            return result
        finally:
            if not self.keep_alive:
                self._close_browser()


def run_account_task(account: dict, browser_config: dict = None, bot: DouyinBot = None) -> dict:
    """
    执行单个账号的续火花任务（给所有好友发消息）
    供 scheduler 调用
    bot: 可选，传入已有bot实例（常驻模式）
    """
    name = account.get("name", "未知")
    friends = account.get("friends", [])
    message = account.get("message", "🔥 续火花")

    result = {
        "account": name,
        "success": 0,
        "failed": 0,
        "details": [],
    }

    if not friends:
        logger.info(f"[{name}] 没有配置好友，跳过")
        return result

    if bot is None:
        bot = DouyinBot(name, browser_config)

    if not bot.is_logged_in():
        logger.warning(f"[{name}] 未登录，跳过")
        result["failed"] = len(friends)
        for f in friends:
            result["details"].append({"friend": f.get("name", "?"), "success": False, "error": "未登录"})
        return result

    send_result = bot.send_to_all(friends, message)
    for r in send_result.get("results", []):
        detail = {"friend": r["friend"], "success": r["success"]}
        if not r["success"]:
            detail["error"] = r.get("error", "")
            result["failed"] += 1
        else:
            result["success"] += 1
        result["details"].append(detail)

    logger.info(f"[{name}] 批量发送完成: {send_result.get('summary', '')}")

    # 发送完成后自动更新火花天数（浏览器还在聊天页，直接抓取）
    try:
        logger.info(f"[{name}] 正在更新好友火花天数...")
        updated_friends = bot._update_spark_days_for_friends(friends)
        if updated_friends:
            result["updated_friends"] = updated_friends
            logger.info(f"[{name}] 火花天数已更新: {len(updated_friends)} 个好友")
    except Exception as e:
        logger.warning(f"[{name}] 更新火花天数失败: {e}")

    return result


def get_active_screenshot():
    """获取当前屏幕截图（bytes），用于网页实时画面
    使用PIL全屏截图，简单可靠"""
    if not DouyinBot._active_bots:
        return None
    try:
        from PIL import ImageGrab, Image
        import io
        img = ImageGrab.grab()
        max_w = 1280
        if img.width > max_w:
            ratio = max_w / img.width
            img = img.resize((max_w, int(img.height * ratio)), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=70)
        return buf.getvalue()
    except Exception as e:
        logger.warning(f"[实时画面] 截图失败: {e}")
        return None