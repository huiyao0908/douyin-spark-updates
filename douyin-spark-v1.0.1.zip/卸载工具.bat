@echo off
chcp 65001 >nul
title 抖音续火花 - 一键卸载

echo ========================================
echo    抖音自动续火花工具 - 一键卸载
echo ========================================
echo.

:: ===== 安全检查：确认当前目录是抖音续火花目录 =====
if not exist "%~dp0app.py" (
    echo [错误] 当前目录不是抖音续火花安装目录！
    echo 请将本脚本放在抖音续火花文件夹内运行。
    echo.
    pause
    exit /b 1
)
if not exist "%~dp0douyin_bot.py" (
    echo [错误] 当前目录不是抖音续火花安装目录！
    echo 缺少 douyin_bot.py 文件。
    echo.
    pause
    exit /b 1
)

echo 即将卸载以下内容：
echo   - 停止抖音续火花服务（端口5000）
echo   - 删除开机自启项
echo   - 删除桌面快捷方式（仅抖音续火花相关）
echo   - 删除当前目录下的程序文件
echo.
echo 注意：不会删除部署包zip、不会影响其他程序
echo.
set /p CONFIRM=确认卸载？输入 Y 继续，其他键取消: 
if /i not "%CONFIRM%"=="Y" (
    echo 已取消卸载。
    pause
    exit /b 0
)
echo.

:: ===== [1/4] 停止服务（仅杀5000端口的进程）=====
echo [1/4] 正在停止服务...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :5000 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
)
echo 服务已停止

:: ===== [2/4] 删除开机自启 =====
echo.
echo [2/4] 正在删除开机自启...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "DouyinSpark" /f >nul 2>&1
echo 开机自启已删除

:: ===== [3/4] 删除桌面快捷方式（仅抖音续火花相关）=====
echo.
echo [3/4] 正在删除桌面快捷方式...
del "%USERPROFILE%\Desktop\抖音续火花管理面板.url" >nul 2>&1
del "%USERPROFILE%\Desktop\启动抖音续火花.lnk" >nul 2>&1
del "%USERPROFILE%\Desktop\停止抖音续火花.lnk" >nul 2>&1
del "%USERPROFILE%\Desktop\抖音续火花.lnk" >nul 2>&1
echo 桌面快捷方式已删除
echo （部署包zip和其他文件保留）

:: ===== [5/5] 卸载 cpolar（国内内网穿透）=====
echo.
echo [5/5] 检查 cpolar...
where cpolar >nul 2>&1
if not errorlevel 1 (
    echo 检测到 cpolar 已安装，正在卸载...
    wmic product where "name like '%%cpolar%%'" call uninstall /nointeractive >nul 2>&1
    if exist "C:\Program Files\cpolar" rmdir /s /q "C:\Program Files\cpolar" 2>nul
    if exist "C:\Program Files (x86)\cpolar" rmdir /s /q "C:\Program Files (x86)\cpolar" 2>nul
    if exist "%USERPROFILE%\.cpolar" rmdir /s /q "%USERPROFILE%\.cpolar" 2>nul
    echo cpolar 已卸载
) else (
    echo 未检测到 cpolar，跳过
)

:: ===== [4/4] 删除程序文件 =====
echo.
echo [4/4] 正在删除程序文件...
cd /d "%~dp0"

:: 删除子目录
for /d %%d in (templates static storage logs screenshots exports deploy_templates __pycache__) do (
    if exist "%%d" rmdir /s /q "%%d" 2>nul
)

:: 删除核心文件
del /q "app.py" 2>nul
del /q "douyin_bot.py" 2>nul
del /q "scheduler.py" 2>nul
del /q "requirements.txt" 2>nul
del /q "config.json" 2>nul
del /q "stats.json" 2>nul
del /q "一键部署.bat" 2>nul
del /q "启动服务.bat" 2>nul
del /q "停止服务.bat" 2>nul
del /q "省电模式开关.bat" 2>nul
del /q "power_save.ps1" 2>nul
del /q "power_save_toggle.ps1" 2>nul
del /q "monitor_off.ps1" 2>nul
del /q "monitor_on.ps1" 2>nul
del /q "一键黑屏.bat" 2>nul
del /q "更新日志.txt" 2>nul
del /q "远程访问一键开启.bat" 2>nul
del /q "使用教程.txt" 2>nul
del /q "使用说明.md" 2>nul
del /q "cloudflared.exe" 2>nul
del /q "ngrok.zip" 2>nul
del /q "ngrok.exe" 2>nul
del /q "开机自启开关.bat" 2>nul
del /q "启动抖音续火花.bat" 2>nul
del /q "停止抖音续火花.bat" 2>nul
del /q "一键启动全部.bat" 2>nul
del /q "一键停止全部.bat" 2>nul
del /q "抖音续火花管理面板.url" 2>nul
del /q "*.lnk" 2>nul
del /q "*.log" 2>nul
del /q "*.pyc" 2>nul

echo 程序文件已删除

echo.
echo ========================================
echo    卸载完成！
echo ========================================
echo.
echo 抖音续火花工具已完全删除。
echo 部署包zip和其他文件未受影响。
echo 这个卸载脚本也可以自行删除。
echo.
pause
