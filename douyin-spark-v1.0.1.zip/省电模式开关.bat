@echo off
chcp 65001 >nul
title 省电模式开关
cd /d "%~dp0"

:: 读取当前状态并切换
for /f "tokens=*" %%a in ('python -c "import json; c=json.load(open('config.json',encoding='utf-8-sig')); ps=c.get('power_save',{}); ps['enabled']=not ps.get('enabled',False); c['power_save']=ps; json.dump(c,open('config.json','w',encoding='utf-8'),ensure_ascii=False,indent=2); print('on' if ps['enabled'] else 'off')"') do set STATE=%%a

if "%STATE%"=="on" (
    echo 正在开启省电模式...
    powershell -ExecutionPolicy Bypass -File "%~dp0power_save.ps1" on
) else (
    echo 正在关闭省电模式...
    powershell -ExecutionPolicy Bypass -File "%~dp0power_save.ps1" off
)

echo.
pause
