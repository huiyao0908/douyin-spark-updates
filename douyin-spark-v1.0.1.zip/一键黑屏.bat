@echo off
chcp 65001 >nul
title 一键黑屏
cd /d "%~dp0"
echo 正在黑屏...
echo 黑屏后屏幕保持熄灭，需手动亮屏或重启电脑恢复。
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0monitor_off.ps1"
echo.
echo 黑屏已执行。
pause
