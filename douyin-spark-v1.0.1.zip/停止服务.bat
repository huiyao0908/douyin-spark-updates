﻿@echo off
chcp 65001 >nul
title 停止抖音续火花服务

echo 正在停止抖音续火花服务...

:: 查找占用5000端口的进程并结束
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":5000" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
    echo 已停止进程 PID: %%a
)

:: 也结束所有pythonw进程（谨慎，可能影响其他python程序）
:: taskkill /F /IM pythonw.exe >nul 2>&1

echo 服务已停止
timeout /t 2 /nobreak >nul
