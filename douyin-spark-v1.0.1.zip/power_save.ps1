﻿# 抖音续火花 - 系统级省电模式
# 参数: on / off
param([string]$mode = "on")

Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public class Audio {
    [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo);
}
'@

# 受保护的进程（不能杀）
$protected = @(
    "python", "pythonw", "cpolar", "msedge", "chrome",
    "explorer", "svchost", "lsass", "csrss", "wininit",
    "services", "smss", "winlogon", "dwm", "fontdrvhost",
    "sihost", "taskhostw", "ShellExperienceHost", "StartMenuExperienceHost",
    "SearchHost", "SearchIndexer", "RuntimeBroker", "backgroundTaskHost",
    "System", "Registry", "Memory Compression", "vmmem",
    "conhost", "cmd", "powershell", "pwsh", "node",
    "NapCatWinBootMain", "QQ", "WeChat", "WeChatAppEx"
)

# 可安全清理的常见后台进程
$cleanable = @(
    "OneDrive", "OneDriveSetup",
    "GoogleUpdate", "MicrosoftEdgeUpdate", "edge_update",
    "AdobeUpdateService", "AdobeARM", "AGSService",
    "iTunesHelper", "AppleMobileDeviceService", "ApplePushService",
    "Spotify", "SpotifyWebHelper",
    "Discord", "DiscordUpdate",
    "Steam", "SteamService", "steamwebhelper",
    "EpicGamesLauncher", "EpicWebHelper",
    "Code", "Code - Insiders", "Cursor",
    "Telegram", "WhatsApp",
    "Skype", "SkypeApp",
    "Slack", "slack",
    "Zoom", "Zoom.exe",
    "Teams", "Teams.exe", "ms-teams",
    "Notion", "Obsidian",
    "Evernote", "EverNote",
    "Dropbox", "DropboxUpdate",
    "WPS", "wps", "wpscenter", "wpscloudsvr",
    "BaiduNetdisk", "baidunetdisk",
    "Thunder", "thunder", "XLLiveUD",
    "QQMusic", "QQMusic", "NeteaseCloudMusic", "cloudmusic",
    "KuGou", "kugou", "Kuwo", "kuwo",
    "iQIYI", "iqiyi", "QQLive", "QQLive",
    "YoudaoDict", "youdaodict", "YoudaoNote",
    "SunloginClient", "sunlogin", "ToDesk", "todesk",
    "AnyDesk", "anydesk", "TeamViewer", "teamviewer",
    "WXWork", "wxwork", "DingTalk", "dingtalk",
    "Feishu", "feishu", "Lark", "lark",
    "360tray", "360sd", "360safe", "ZhuDongFangYu",
    "QQPCRTP", "QQPCTray", "QQPCMgr",
    "2345SafeCenter", "2345tray", "2345Explorer",
    "RavMonD", "RavTask", "RavMon",
    "KWatch", "KAVStart", "KSafe",
    "HipsTray", "HipsDaemon", "kwsprotect64",
    "wsctrl", "wscsvc", "wscntfy"
)

if ($mode -eq "on") {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  抖音续火花 - 省电模式开启" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan

    # 1. 系统静音
    [Audio]::keybd_event(0xAD, 0, 0, 0)
    [Audio]::keybd_event(0xAD, 0, 2, 0)
    Write-Host "[1/6] 系统已静音"

    # 2. 电源计划：平衡模式，显示器10分钟关，睡眠从不
    powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e | Out-Null
    powercfg /change monitor-timeout-ac 10 | Out-Null
    powercfg /change standby-timeout-ac 0 | Out-Null
    powercfg /change disk-timeout-ac 0 | Out-Null
    Write-Host "[2/6] 电源计划: 显示器10分钟关, 睡眠从不"

    # 3. CPU最大70%（保留足够性能运行续火花）
    powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 70 | Out-Null
    powercfg /setactive SCHEME_CURRENT | Out-Null
    Write-Host "[3/6] CPU最大状态: 70%"

    # 4. 禁用USB选择性暂停
    powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0 | Out-Null
    powercfg /setactive SCHEME_CURRENT | Out-Null
    Write-Host "[4/6] USB选择性暂停: 已禁用"

    # 5. 清理无用后台进程
    $killed = @()
    foreach ($name in $cleanable) {
        $procs = Get-Process -Name $name -ErrorAction SilentlyContinue
        foreach ($p in $procs) {
            if ($protected -notcontains $p.ProcessName) {
                try {
                    Stop-Process -Id $p.Id -Force -ErrorAction Stop
                    $killed += "$($p.ProcessName)($($p.Id))"
                } catch {}
            }
        }
    }
    if ($killed.Count -gt 0) {
        Write-Host "[5/6] 已清理无用进程: $($killed.Count)个" -ForegroundColor Yellow
        $killed | ForEach-Object { Write-Host "      - $_" -ForegroundColor DarkGray }
    } else {
        Write-Host "[5/6] 无用进程清理: 无需清理"
    }

    # 6. 进程优先级低于正常
    Get-Process -Name python,pythonw,NapCatWinBootMain -ErrorAction SilentlyContinue | ForEach-Object {
        $_.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::BelowNormal
    }
    Write-Host "[6/6] 进程优先级: 低于正常"

    Write-Host ""
    Write-Host "  省电模式已启用！" -ForegroundColor Green
    Write-Host "  - 系统静音"
    Write-Host "  - 显示器10分钟关闭"
    Write-Host "  - 睡眠从不（保持在线）"
    Write-Host "  - CPU最大70%"
    Write-Host "  - 已清理无用后台进程"
}
else {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  抖音续火花 - 恢复默认设置" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan

    # 1. 取消静音
    [Audio]::keybd_event(0xAD, 0, 0, 0)
    [Audio]::keybd_event(0xAD, 0, 2, 0)
    Write-Host "[1/5] 系统已取消静音"

    # 2. 恢复电源计划默认
    powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e | Out-Null
    powercfg /change monitor-timeout-ac 10 | Out-Null
    powercfg /change standby-timeout-ac 30 | Out-Null
    powercfg /change disk-timeout-ac 20 | Out-Null
    Write-Host "[2/5] 电源计划: 显示器10分钟, 睡眠30分钟"

    # 3. CPU恢复100%
    powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100 | Out-Null
    powercfg /setactive SCHEME_CURRENT | Out-Null
    Write-Host "[3/5] CPU最大状态: 100%"

    # 4. 恢复USB选择性暂停
    powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 1 | Out-Null
    powercfg /setactive SCHEME_CURRENT | Out-Null
    Write-Host "[4/5] USB选择性暂停: 已启用"

    # 5. 恢复进程优先级
    Get-Process -Name python,pythonw,NapCatWinBootMain -ErrorAction SilentlyContinue | ForEach-Object {
        $_.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::Normal
    }
    Write-Host "[5/5] 进程优先级: 正常"

    Write-Host ""
    Write-Host "  已恢复默认设置！" -ForegroundColor Green
    Write-Host "  注意: 被清理的进程需要手动重新打开" -ForegroundColor Yellow
}
