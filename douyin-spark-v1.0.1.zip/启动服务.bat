@echo off
chcp 65001 >nul
title 抖音续火花 - 服务
cd /d "%~dp0"

echo 正在启动抖音续火花服务...
echo 管理面板: http://127.0.0.1:5000
echo.

:: 检查是否已在运行
netstat -ano | findstr ":5000" | findstr "LISTENING" >nul
if %errorlevel%==0 (
    echo 服务已在运行中，直接打开管理面板
    start "" http://127.0.0.1:5000
    exit /b 0
)

:: 用 pythonw 后台运行（无命令行窗口），不可用则用 python
where pythonw >nul 2>&1
if %errorlevel%==0 (
    start "" /B pythonw app.py
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        start "" /B python app.py
    ) else (
        echo [错误] 未检测到 Python！请先运行 "一键部署.bat"
        pause
        exit /b 1
    )
)

:: 等待启动
timeout /t 5 /nobreak >nul

:: 验证启动
netstat -ano | findstr ":5000" | findstr "LISTENING" >nul
if %errorlevel%==0 (
    echo 服务启动成功！
    start "" http://127.0.0.1:5000
    echo.
    echo ========================================
    echo   是否开启省电模式？
    echo   省电模式会：
    echo   - 系统静音
    echo   - 显示器10分钟自动关闭
    echo   - CPU限制到70%%
    echo   - 清理无用后台进程（释放内存）
    echo   注意：清理进程会关闭正在运行的其他软件
    echo ========================================
    choice /c YN /n /m "开启省电模式？(Y/N): "
    if %errorlevel%==1 (
        echo 正在开启省电模式...
        powershell -ExecutionPolicy Bypass -File "%~dp0power_save.ps1" on
    ) else (
        echo 已跳过省电模式
    )
) else (
    echo.
    echo 启动失败！请检查：
    echo   1. Python 是否已安装并加入 PATH
    echo   2. 是否运行过 "一键部署.bat" 安装依赖
    echo   3. 端口 5000 是否被其他程序占用
    echo.
    echo 尝试用以下命令查看错误：
    echo   python app.py
    echo.
    pause
)
