"""
抖音自动续火花 - Web 管理界面
Flask 应用主入口
"""
import os
import json
import logging
import logging.handlers
import threading
import queue
import time
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, Response, make_response

from scheduler import SparkScheduler
from douyin_bot import DouyinBot, cancel_send, _load_stats

# ===== 日志配置 =====
BASE_DIR = Path(__file__).parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.handlers.RotatingFileHandler(LOG_DIR / "app.log", maxBytes=5*1024*1024, backupCount=3, encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("douyin_spark")

# 统一版本号（唯一来源，检查更新/界面都读它）
APP_VERSION = "V1.0.3"

# 屏蔽后台噪音日志：只保留功能性消息
logging.getLogger("werkzeug").setLevel(logging.WARNING)
logging.getLogger("apscheduler").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

# ===== 截图自动清理：保留最近20张，删除旧的 =====
def cleanup_screenshots(keep_last=20):
    try:
        import glob
        shot_dir = BASE_DIR / "screenshots"
        shot_dir.mkdir(exist_ok=True)
        files = sorted(glob.glob(str(shot_dir / "*.png")), key=os.path.getmtime, reverse=True)
        if len(files) > keep_last:
            for f in files[keep_last:]:
                os.remove(f)
            logger.info(f"截图清理: 删除{len(files)-keep_last}张旧截图，保留最近{keep_last}张")
    except Exception as e:
        logger.error(f"截图清理失败: {e}")

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.jinja_env.auto_reload = True
app.config["JSON_AS_ASCII"] = False

# 全局错误处理：API错误返回JSON而不是HTML
@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "error": "接口不存在"}), 404
    return e, 404

@app.errorhandler(500)
def server_error(e):
    logger.error(f"服务器错误: {e}", exc_info=True)
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "error": f"服务器内部错误: {e}"}), 500
    return e, 500

@app.errorhandler(Exception)
def handle_exception(e):
    logger.error(f"未捕获异常: {e}", exc_info=True)
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "error": str(e)}), 500
    raise e

CONFIG_FILE = BASE_DIR / "config.json"
scheduler = SparkScheduler()

# 常驻浏览器工作线程管理：{account_index: KeepAliveWorker}
_keepalive_workers = {}
_keepalive_lock = threading.Lock()

# 刷新火花任务状态
_spark_refresh_running = False


class KeepAliveWorker:
    """常驻浏览器工作线程：所有操作在同一线程执行，浏览器可复用"""
    def __init__(self, idx, account_name, browser_config):
        self.idx = idx
        self.account_name = account_name
        self.browser_config = browser_config
        self.bot = None
        self._task_queue = queue.Queue()
        self._thread = None
        self._running = False

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name=f"keepalive-{self.idx}")
        self._thread.start()
        logger.info(f"账号{self.idx} 常驻工作线程已启动")

    def _loop(self):
        """工作线程主循环"""
        self.bot = DouyinBot(self.account_name, self.browser_config)
        self.bot.keep_alive = True
        while self._running:
            try:
                task = self._task_queue.get(timeout=1)
                if task is None:  # 停止信号
                    break
                func, result_holder, error_holder = task
                try:
                    result_holder["result"] = func(self.bot)
                except Exception as e:
                    error_holder["error"] = e
                    logger.error(f"账号{self.idx} 常驻任务异常: {e}")
                finally:
                    result_holder["done"] = True
                    # 操作完成后切回管理面板
                    try:
                        if self.bot:
                            self.bot.task_complete()
                    except Exception:
                        pass
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"账号{self.idx} 常驻线程异常: {e}")
        # 线程结束，关闭浏览器
        try:
            if self.bot:
                self.bot._close_browser()
        except Exception:
            pass
        logger.info(f"账号{self.idx} 常驻工作线程已结束")

    def submit(self, func, timeout=120):
        """提交任务到工作线程执行，等待结果返回"""
        self.start()  # 确保线程在运行
        result_holder = {"done": False, "result": None}
        error_holder = {"error": None}
        self._task_queue.put((func, result_holder, error_holder))
        # 等待结果
        waited = 0
        while not result_holder["done"] and waited < timeout:
            time.sleep(0.2)
            waited += 0.2
        if not result_holder["done"]:
            raise TimeoutError("常驻任务执行超时")
        if error_holder["error"]:
            raise error_holder["error"]
        return result_holder["result"]

    def stop(self):
        self._running = False
        self._task_queue.put(None)  # 发送停止信号
        if self._thread:
            self._thread.join(timeout=5)


def get_keepalive_worker(idx, account_name, browser_config):
    """获取常驻工作线程实例"""
    with _keepalive_lock:
        if idx in _keepalive_workers:
            worker = _keepalive_workers[idx]
            worker.account_name = account_name
            worker.browser_config = browser_config
            if worker.bot:
                worker.bot.browser_config = browser_config or {}
            return worker
        worker = KeepAliveWorker(idx, account_name, browser_config)
        _keepalive_workers[idx] = worker
        return worker


def close_keepalive_bot(idx):
    """关闭并移除常驻工作线程"""
    with _keepalive_lock:
        if idx in _keepalive_workers:
            try:
                _keepalive_workers[idx].stop()
            except Exception:
                pass
            del _keepalive_workers[idx]
            logger.info(f"账号{idx} 常驻工作线程已关闭")


DEFAULT_CONFIG = {
    "accounts": [],
    "browser": {"headless": False, "slow_mo": 50},
    "schedule": {"enabled": True, "hour": 0, "minute": 30, "per_account": {}},
    "power_save": False,
    "live_view_enabled": True,
    "low_performance_mode": False,
    "monitor_control_enabled": False,
    "background": ""
}

def load_config():
    """加载配置，文件不存在或损坏时自动创建默认配置"""
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8-sig") as f:
            cfg = json.load(f)
        for k, v in DEFAULT_CONFIG.items():
            if k not in cfg:
                cfg[k] = v
        if "accounts" not in cfg:
            cfg["accounts"] = []
        return cfg
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning(f"配置文件不存在或损坏，使用默认配置: {e}")
        save_config(DEFAULT_CONFIG)
        return json.loads(json.dumps(DEFAULT_CONFIG))


def save_config(config):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def get_effective_browser_config(config):
    """获取有效的浏览器配置（省电模式开启时使用省电配置）"""
    browser = dict(config.get("browser", {}))
    ps = config.get("power_save", {})
    # 兼容power_save为bool值的情况
    if isinstance(ps, bool):
        ps = {"enabled": ps}
    if isinstance(ps, dict) and ps.get("enabled"):
        if ps.get("headless") is not None:
            browser["headless"] = ps["headless"]
        if ps.get("slow_mo") is not None:
            browser["slow_mo"] = ps["slow_mo"]
    return browser


# ===== 页面路由 =====
@app.route("/")
def index():
    resp = make_response(render_template("index.html"))
    # 禁止缓存HTML，确保更新后用户拿到最新页面
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


# ===== API: 配置 =====
@app.route("/api/config", methods=["GET"])
def get_config():
    config = load_config()
    # 附加每个账号的登录状态
    for acc in config.get("accounts", []):
        bot = DouyinBot(acc["name"], get_effective_browser_config(config))
        acc["logged_in"] = bot.is_logged_in()
    return jsonify(config)


@app.route("/api/config", methods=["POST"])
def update_config():
    data = request.json
    save_config(data)
    # 如果调度配置变了，重新设置
    sched = data.get("schedule", {})
    scheduler.reschedule(
        hour=sched.get("hour", 9),
        minute=sched.get("minute", 0),
        enabled=sched.get("enabled", True),
    )
    return jsonify({"success": True, "message": "配置已保存"})


# ===== API: 省电模式开关 =====
@app.route("/api/power_save", methods=["GET"])
def get_power_save():
    config = load_config()
    return jsonify(config.get("power_save", {"enabled": False}))


@app.route("/api/power_save/toggle", methods=["POST"])
def toggle_power_save():
    config = load_config()
    ps = config.get("power_save", {"enabled": False})
    ps["enabled"] = not ps.get("enabled", False)
    config["power_save"] = ps
    save_config(config)
    status = "已开启" if ps["enabled"] else "已关闭"
    logger.info(f"省电模式{status}")

    # 调用系统级省电脚本
    try:
        mode = "on" if ps["enabled"] else "off"
        ps_script = BASE_DIR / "power_save.ps1"
        if ps_script.exists():
            import subprocess
            subprocess.Popen(
                ["powershell", "-ExecutionPolicy", "Bypass", "-File", str(ps_script), "-mode", mode],
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            logger.info(f"已调用系统省电脚本: {mode}")
    except Exception as e:
        logger.error(f"调用省电脚本失败: {e}")

    return jsonify({"success": True, "enabled": ps["enabled"], "message": f"省电模式{status}"})


# ===== API: 账号管理 =====
@app.route("/api/accounts", methods=["GET"])
def get_accounts():
    config = load_config()
    accounts = []
    for acc in config.get("accounts", []):
        bot = DouyinBot(acc["name"], get_effective_browser_config(config))
        # 如果之前验证登录失败，强制显示未登录
        is_valid = not acc.get("login_invalid", False)
        accounts.append({
            **acc,
            "enabled": acc.get("enabled", True),
            "keep_alive": acc.get("keep_alive", False),
            "logged_in": bot.is_logged_in() and is_valid,
        })
    return jsonify(accounts)


@app.route("/api/accounts/<int:idx>", methods=["PUT"])
def update_account(idx):
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404
    config["accounts"][idx].update(request.json)
    save_config(config)
    return jsonify({"success": True})


@app.route("/api/accounts", methods=["POST"])
def add_account():
    try:
        config = load_config()
        new_acc = request.get_json(silent=True) or {}
        if "name" not in new_acc or not new_acc.get("name"):
            new_acc["name"] = f"账号{len(config['accounts'])+1}"
        if "friends" not in new_acc:
            new_acc["friends"] = []
        if "message" not in new_acc:
            new_acc["message"] = "🔥 今天也要开心呀~"
        if "logged_in" not in new_acc:
            new_acc["logged_in"] = False
        if "keep_alive" not in new_acc:
            new_acc["keep_alive"] = False
        if "enabled" not in new_acc:
            new_acc["enabled"] = True
        if "login_invalid" not in new_acc:
            new_acc["login_invalid"] = False
        config["accounts"].append(new_acc)
        save_config(config)
        idx = len(config["accounts"]) - 1
        return jsonify({"success": True, "account_index": idx})
    except Exception as e:
        logger.error(f"添加账号失败: {e}", exc_info=True)
        return jsonify({"success": False, "error": f"添加失败: {e}"}), 500


@app.route("/api/accounts/<int:idx>", methods=["DELETE"])
def delete_account(idx):
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404
    removed = config["accounts"].pop(idx)
    # 关闭常驻浏览器实例
    close_keepalive_bot(idx)
    # 删除对应的 storage 文件
    storage_file = BASE_DIR / "storage" / f"{removed['name']}.json"
    if storage_file.exists():
        storage_file.unlink()
    save_config(config)
    return jsonify({"success": True})


@app.route("/api/accounts/<int:idx>/logout", methods=["POST"])
def logout_account(idx):
    """退出登录：删除storage文件，标记login_invalid=True"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404
    acc = config["accounts"][idx]
    name = acc.get("name", "")
    # 关闭常驻浏览器
    close_keepalive_bot(idx)
    # 删除storage文件
    storage_file = BASE_DIR / "storage" / f"{name}.json"
    deleted = False
    if storage_file.exists():
        storage_file.unlink()
        deleted = True
    # 标记登录失效并清空旧好友（防止新账号看到旧账号的好友）
    config["accounts"][idx]["login_invalid"] = True
    config["accounts"][idx]["friends"] = []
    save_config(config)
    logger.info(f"账号[{idx}] {name} 已退出登录（storage删除: {deleted}，好友列表已清空）")
    return jsonify({"success": True, "message": "已退出登录"})


# ===== API: 登录（扫码） =====
@app.route("/api/login/<int:idx>", methods=["POST"])
def login_account(idx):
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404

    acc = config["accounts"][idx]
    bot = DouyinBot(acc["name"], get_effective_browser_config(config))

    def do_login():
        result = bot.login(timeout=300)
        logger.info(f"登录结果: {result.get('message', '未知')}")
        # 登录完成后，无论检测结果如何，都验证存储状态并更新配置
        try:
            cfg = load_config()
            old_name = cfg["accounts"][idx]["name"]
            # 检查保存的状态是否有效
            temp_bot = DouyinBot(old_name, get_effective_browser_config(cfg))
            actually_logged_in = temp_bot.is_logged_in()
            # 更新用户名（如果login获取到了）
            new_name = result.get("username", "")
            if not new_name:
                new_name = old_name  # 没获取到就用旧名称
            if old_name != new_name and new_name:
                # 重命名存储文件
                old_storage = BASE_DIR / "storage" / f"{old_name}.json"
                new_storage = BASE_DIR / "storage" / f"{new_name}.json"
                if old_storage.exists() and not new_storage.exists():
                    old_storage.rename(new_storage)
                cfg["accounts"][idx]["name"] = new_name
                # 用户名变了说明登的是不同账号，清空旧好友
                cfg["accounts"][idx]["friends"] = []
                logger.info(f"账号名称已更新: {old_name} -> {new_name}，旧好友列表已清空")
            # 更新登录状态标记
            cfg["accounts"][idx]["login_invalid"] = not actually_logged_in
            save_config(cfg)
            logger.info(f"账号[{idx}] 登录状态: logged_in={actually_logged_in}, login_invalid={not actually_logged_in}")
            # 如果实际已登录但检测说失败，修正result
            if actually_logged_in and not result.get("success"):
                result["success"] = True
                result["message"] = "登录成功（状态验证通过）"
        except Exception as e:
            logger.error(f"更新登录状态失败: {e}")

    # 在后台线程执行登录，完成后持续截图
    def do_login_and_keep():
        do_login()
        try:
            for b in DouyinBot._active_bots:
                b._keep_shooting = True
                while getattr(b, "_keep_shooting", False) and b._page and not b._page.is_closed():
                    try:
                        b._update_screenshot_cache()
                    except Exception:
                        pass
                    import time as _t
                    _t.sleep(0.5)
        except Exception as e:
            logger.debug(f"持续截图结束: {e}")

    thread = threading.Thread(target=do_login_and_keep, daemon=True)
    thread.start()

    return jsonify({
        "success": True,
        "message": "浏览器窗口已弹出，请在 5 分钟内扫码登录",
    })


@app.route("/api/login/status/<account_name>", methods=["GET"])
def login_status(account_name):
    config = load_config()
    bot = DouyinBot(account_name, get_effective_browser_config(config))
    return jsonify({"logged_in": bot.is_logged_in()})


# ===== 临时存储：好友同步结果 =====
_sync_results = {}
_verify_all_results = {"status": "idle", "results": [], "total": 0, "done": 0}


@app.route("/api/accounts/<int:idx>/verify-login", methods=["POST"])
def verify_login(idx):
    """验证登录状态是否仍然有效（实际打开浏览器检查）"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404

    acc = config["accounts"][idx]
    use_keepalive = acc.get("keep_alive", False)

    if use_keepalive:
        # 常驻模式：通过工作线程执行（同一线程复用浏览器）
        logger.info(f"账号{idx} 使用常驻浏览器验证登录")
        worker = get_keepalive_worker(idx, acc["name"], get_effective_browser_config(config))
        try:
            result = worker.submit(lambda b: b.verify_login(), timeout=60)
        except Exception as e:
            return jsonify({"success": False, "valid": False, "message": f"验证异常: {e}"})
    else:
        bot = DouyinBot(acc["name"], get_effective_browser_config(config))
        result_holder = {}
        def do_verify():
            result_holder["data"] = bot.verify_login()
        thread = threading.Thread(target=do_verify, daemon=True)
        thread.start()
        thread.join(timeout=60)
        if "data" not in result_holder:
            return jsonify({"success": False, "valid": False, "message": "验证超时"})
        result = result_holder["data"]

    # 验证失败时标记，成功时清除标记
    cfg = load_config()
    if result.get("valid"):
        cfg["accounts"][idx]["login_invalid"] = False
    else:
        cfg["accounts"][idx]["login_invalid"] = True
    save_config(cfg)
    return jsonify({"success": True, **result})


@app.route("/api/verify-all", methods=["POST"])
def verify_all_logins():
    """一键检查所有账号登录状态（后台逐个验证）"""
    config = load_config()
    accounts = config.get("accounts", [])
    if not accounts:
        return jsonify({"success": False, "error": "暂无账号，请先添加账号"}), 400

    global _verify_all_results
    _verify_all_results = {"status": "running", "results": [], "total": len(accounts), "done": 0}

    def do_verify_all():
        global _verify_all_results
        for i, acc in enumerate(accounts):
            try:
                use_keepalive = acc.get("keep_alive", False)
                if use_keepalive:
                    worker = get_keepalive_worker(i, acc["name"], get_effective_browser_config(config))
                    result = worker.submit(lambda b: b.verify_login(), timeout=60)
                else:
                    bot = DouyinBot(acc["name"], get_effective_browser_config(config))
                    holder = {}
                    def run(bot=bot):
                        holder["data"] = bot.verify_login()
                    t = threading.Thread(target=run, daemon=True)
                    t.start()
                    t.join(timeout=60)
                    result = holder.get("data", {"valid": False, "message": "验证超时"})

                valid = result.get("valid", False)
                cfg = load_config()
                cfg["accounts"][i]["login_invalid"] = not valid
                save_config(cfg)
                _verify_all_results["results"].append({
                    "index": i, "name": acc["name"], "valid": valid,
                    "message": result.get("message", "")
                })
                _verify_all_results["done"] = i + 1
                logger.info(f"[一键检查] 账号{i}({acc['name']}): {'有效' if valid else '失效'}")
            except Exception as e:
                _verify_all_results["results"].append({
                    "index": i, "name": acc["name"], "valid": False, "message": str(e)
                })
                _verify_all_results["done"] = i + 1
        _verify_all_results["status"] = "done"

    thread = threading.Thread(target=do_verify_all, daemon=True)
    thread.start()
    return jsonify({"success": True, "message": f"开始检查 {len(accounts)} 个账号的登录状态..."})


@app.route("/api/verify-all/status", methods=["GET"])
def verify_all_status():
    """获取一键检查登录状态的进度"""
    return jsonify(_verify_all_results)


@app.route("/api/accounts/<int:idx>/keep-alive", methods=["POST"])
def set_keep_alive(idx):
    """设置账号浏览器常驻开关"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404
    data = request.get_json(silent=True) or {}
    keep_alive = bool(data.get("keep_alive", False))
    config["accounts"][idx]["keep_alive"] = keep_alive
    save_config(config)
    if not keep_alive:
        close_keepalive_bot(idx)
        logger.info(f"账号{idx} 已关闭浏览器常驻")
    else:
        logger.info(f"账号{idx} 已开启浏览器常驻")
    return jsonify({"success": True, "keep_alive": keep_alive})


@app.route("/api/accounts/<int:idx>/toggle", methods=["POST"])
def toggle_account(idx):
    """启用/禁用账号"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404
    config["accounts"][idx]["enabled"] = not config["accounts"][idx].get("enabled", True)
    save_config(config)
    status = "已启用" if config["accounts"][idx]["enabled"] else "已禁用"
    logger.info(f"账号{idx} {status}")
    return jsonify({"success": True, "enabled": config["accounts"][idx]["enabled"]})


@app.route("/api/accounts/<int:idx>/sync-friends", methods=["POST"])
def sync_friends(idx):
    """触发同步好友列表（后台执行，带实时状态反馈）"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404

    acc = config["accounts"][idx]
    use_keepalive = acc.get("keep_alive", False)

    # is_logged_in只检查文件，不需要浏览器
    temp_bot = DouyinBot(acc["name"], get_effective_browser_config(config))
    if not temp_bot.is_logged_in():
        return jsonify({"success": False, "error": "请先扫码登录"}), 400

    _sync_results[idx] = {
        "status": "running",
        "step": "start",
        "message": "正在启动...",
        "friends": [],
        "error": "",
    }

    def status_callback(step, message):
        _sync_results[idx] = {
            "status": "running",
            "step": step,
            "message": message,
            "friends": _sync_results[idx].get("friends", []),
            "error": "",
        }

    def do_sync():
        try:
            if use_keepalive:
                worker = get_keepalive_worker(idx, acc["name"], get_effective_browser_config(config))
                result = worker.submit(lambda b: b.get_friends_list(status_callback=status_callback), timeout=180)
            else:
                bot = DouyinBot(acc["name"], get_effective_browser_config(config))
                result = bot.get_friends_list(status_callback=status_callback)
            if result["success"]:
                _sync_results[idx] = {
                    "status": "done",
                    "step": "done",
                    "message": f"抓取完成，共 {len(result['friends'])} 个好友",
                    "friends": result["friends"],
                    "error": "",
                    "screenshot": result.get("screenshot", ""),
                }
                logger.info(f"[{acc['name']}] 同步好友完成，共 {len(result['friends'])} 个")
            else:
                _sync_results[idx] = {
                    "status": "error",
                    "step": "error",
                    "message": result["error"],
                    "friends": [],
                    "error": result["error"],
                    "screenshot": result.get("screenshot", ""),
                }
                logger.error(f"[{acc['name']}] 同步好友失败: {result['error']}")
        except Exception as e:
            logger.error(f"[{acc['name']}] 同步好友异常: {e}", exc_info=True)
            _sync_results[idx] = {
                "status": "error",
                "step": "error",
                "message": f"异常: {e}",
                "friends": [],
                "error": str(e),
            }

    thread = threading.Thread(target=do_sync, daemon=True)
    thread.start()
    return jsonify({"success": True, "message": "正在同步好友列表..."})


@app.route("/api/accounts/<int:idx>/sync-result", methods=["GET"])
def get_sync_result(idx):
    """获取同步好友的结果（含实时步骤状态）"""
    result = _sync_results.get(idx, {
        "status": "none", "step": "none", "message": "", "friends": [], "error": ""
    })
    return jsonify(result)


@app.route("/api/accounts/<int:idx>/import-friends", methods=["POST"])
def import_friends(idx):
    """将选中的好友导入到账号配置中"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404

    data = request.json
    selected_friends = data.get("friends", [])
    replace = data.get("replace", False)  # 替换模式：先清空旧好友再添加
    # 兼容旧版只传names的情况
    if not selected_friends and "names" in data:
        selected_friends = [{"name": n} for n in data["names"]]

    # 替换模式：先清空旧好友
    if replace:
        config["accounts"][idx]["friends"] = []

    existing = {f["name"] for f in config["accounts"][idx].get("friends", [])}
    added = 0
    existed = 0
    for f in selected_friends:
        name = f.get("name", "") if isinstance(f, dict) else str(f)
        if name:
            if name not in existing:
                friend_entry = {"name": name, "remark": ""}
                if isinstance(f, dict) and f.get("spark_days"):
                    friend_entry["spark_days"] = f["spark_days"]
                config["accounts"][idx]["friends"].append(friend_entry)
                existing.add(name)
                added += 1
            else:
                # 已存在的好友也更新火花天数
                if isinstance(f, dict) and f.get("spark_days"):
                    for ef in config["accounts"][idx]["friends"]:
                        if ef["name"] == name:
                            ef["spark_days"] = f["spark_days"]
                            break
                existed += 1

    save_config(config)
    return jsonify({
        "success": True,
        "added": added,
        "existed": existed,
        "message": f"新增 {added} 个好友" + (f"，{existed} 个已存在" if existed > 0 else "")
    })


@app.route("/api/accounts/<int:idx>/spark/<int:friend_idx>", methods=["GET"])
def get_spark_days(idx, friend_idx):
    """获取指定好友的火花天数（尝试性抓取）"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404

    acc = config["accounts"][idx]
    friends = acc.get("friends", [])
    if friend_idx < 0 or friend_idx >= len(friends):
        return jsonify({"success": False, "error": "好友索引越界"}), 404

    friend = friends[friend_idx]
    bot = DouyinBot(acc["name"], get_effective_browser_config(config))

    if not bot.is_logged_in():
        return jsonify({"success": False, "error": "请先登录"}), 400

    def do_check():
        return bot.get_spark_days(friend["name"], friend.get("remark", ""))

    thread_result = {}

    def worker():
        thread_result["data"] = do_check()

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    thread.join(timeout=60)

    if "data" in thread_result:
        return jsonify({"success": True, **thread_result["data"]})
    else:
        return jsonify({"success": False, "error": "查询超时"})


@app.route("/api/spark/refresh-all", methods=["POST"])
def refresh_all_spark_days():
    """一键刷新所有已登录账号的好友火花天数"""
    if scheduler.is_running():
        return jsonify({"success": False, "error": "有发送任务正在执行，请稍后再试"}), 409

    global _spark_refresh_running
    if _spark_refresh_running:
        return jsonify({"success": False, "error": "火花刷新正在进行中，请稍候"}), 409

    def do_refresh():
        config = load_config()
        total_updated = 0
        results = []
        for idx, acc in enumerate(config.get("accounts", [])):
            if not acc.get("enabled", True):
                continue
            name = acc.get("name", "")
            use_keepalive = acc.get("keep_alive", False)
            updated = []
            try:
                logger.info(f"[刷新火花] 开始处理账号: {name}")
                if use_keepalive:
                    worker = get_keepalive_worker(idx, name, get_effective_browser_config(config))
                    def do_refresh_ka(bot, friends=acc.get("friends", [])):
                        DouyinBot._active_bots.append(bot)
                        try:
                            if not bot._open_chat_page():
                                return []
                            return bot._update_spark_days_for_friends(friends)
                        finally:
                            if bot in DouyinBot._active_bots:
                                DouyinBot._active_bots.remove(bot)
                    updated = worker.submit(do_refresh_ka, timeout=120)
                else:
                    bot = DouyinBot(name, get_effective_browser_config(config))
                    if not bot.is_logged_in():
                        results.append({"account": name, "status": "skipped", "reason": "未登录"})
                        continue
                    bot._start_browser(use_storage=True)
                    DouyinBot._active_bots.append(bot)
                    try:
                        if not bot._open_chat_page():
                            results.append({"account": name, "status": "error", "reason": "无法打开聊天页"})
                        else:
                            updated = bot._update_spark_days_for_friends(acc.get("friends", []))
                    finally:
                        if bot in DouyinBot._active_bots:
                            DouyinBot._active_bots.remove(bot)
                        try:
                            bot._close_browser()  # 直接关闭浏览器，确保资源释放
                        except Exception:
                            pass
                total_updated += len(updated)
                results.append({"account": name, "status": "success", "updated": len(updated)})
                logger.info(f"[刷新火花] {name}: 更新了 {len(updated)} 个好友")
            except Exception as e:
                results.append({"account": name, "status": "error", "reason": str(e)})
                logger.error(f"[刷新火花] {name} 失败: {e}")
            # 账号之间延迟3秒，确保Playwright资源完全释放
            import time
            time.sleep(3)
        logger.info(f"[刷新火花] 全部完成，共更新 {total_updated} 个好友")
        global _spark_refresh_running
        _spark_refresh_running = False
        return {"total_updated": total_updated, "results": results}

    thread = threading.Thread(target=lambda: do_refresh(), daemon=True)
    thread.start()
    _spark_refresh_running = True
    return jsonify({"success": True, "message": "正在刷新所有账号火花天数，请稍候..."})


# ===== API: 发送消息 =====
@app.route("/api/send/all", methods=["POST"])
def send_all():
    """手动触发所有账号发送"""
    if scheduler.is_running():
        return jsonify({"success": False, "error": "任务正在执行中"}), 409

    def do_send():
        scheduler.execute_all(trigger_type="manual")

    thread = threading.Thread(target=do_send, daemon=True)
    thread.start()
    return jsonify({"success": True, "message": "任务已开始执行"})


@app.route("/api/send/account/<int:idx>", methods=["POST"])
def send_account(idx):
    """手动触发单个账号发送"""
    config = load_config()
    if idx < 0 or idx >= len(config["accounts"]):
        return jsonify({"success": False, "error": "账号索引越界"}), 404

    if scheduler.is_running():
        return jsonify({"success": False, "error": "有任务正在执行中"}), 409

    acc = config["accounts"][idx]
    use_keepalive = acc.get("keep_alive", False)

    def do_send():
        from douyin_bot import run_account_task, reset_cancel_send
        reset_cancel_send()
        scheduler._running = True
        try:
            if use_keepalive:
                worker = get_keepalive_worker(idx, acc["name"], get_effective_browser_config(config))
                result = worker.submit(
                    lambda b: run_account_task(acc, get_effective_browser_config(config), bot=b),
                    timeout=300
                )
            else:
                result = run_account_task(acc, get_effective_browser_config(config))
            # 记录到历史
            record = {
                "trigger": "manual_single",
                "start_time": datetime.now().isoformat(),
                "end_time": datetime.now().isoformat(),
                "accounts": [result],
                "total_success": result["success"],
                "total_failed": result["failed"],
            }
            scheduler._save_history(record)
            scheduler._last_run = record
        finally:
            scheduler._running = False

    thread = threading.Thread(target=do_send, daemon=True)
    thread.start()
    return jsonify({"success": True, "message": f"账号 {acc['name']} 任务已开始"})


@app.route("/api/send/cancel", methods=["POST"])
def cancel_send_task():
    """取消正在执行的发送任务（停止所有账号）"""
    scheduler.cancel()
    logger.info("用户请求取消发送（全部账号）")
    return jsonify({"success": True, "message": "已取消，所有账号将停止发送"})


# ===== API: 状态和历史 =====
@app.route("/api/status", methods=["GET"])
def get_status():
    stats = _load_stats()
    config = load_config()
    return jsonify({
        "running": scheduler.is_running(),
        "last_run": scheduler.get_last_run(),
        "next_run": scheduler.get_next_run_time(),
        "current_time": datetime.now().isoformat(),
        "total_success": stats.get("total_success", 0),
        "first_run": stats.get("first_run"),
        "monitor_control_enabled": config.get("monitor_control_enabled", False),
    })


@app.route("/api/history", methods=["GET"])
def get_history():
    limit = request.args.get("limit", 20, type=int)
    return jsonify(scheduler.get_history(limit=limit))


@app.route("/api/network-info", methods=["GET"])
def get_network_info():
    """获取局域网IP等网络信息"""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        lan_ip = s.getsockname()[0]
        s.close()
    except Exception:
        lan_ip = "127.0.0.1"
    return jsonify({
        "lan_ip": lan_ip,
        "local_url": "http://127.0.0.1:5000",
        "lan_url": f"http://{lan_ip}:5000",
    })


# ===== 系统状态 =====
import ctypes as _ctypes
import platform as _platform
import shutil as _shutil

_SERVICE_START = time.time()


class _MEMORYSTATUSEX(_ctypes.Structure):
    _fields_ = [
        ("dwLength", _ctypes.c_ulong), ("dwMemoryLoad", _ctypes.c_ulong),
        ("ullTotalPhys", _ctypes.c_ulonglong), ("ullAvailPhys", _ctypes.c_ulonglong),
        ("ullTotalPageFile", _ctypes.c_ulonglong), ("ullAvailPageFile", _ctypes.c_ulonglong),
        ("ullTotalVirtual", _ctypes.c_ulonglong), ("ullAvailVirtual", _ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", _ctypes.c_ulonglong),
    ]


_cpu_last = None


def _cpu_percent():
    """两次 GetSystemTimes 采样之间的 CPU 占用率（%）"""
    global _cpu_last

    class _FT(_ctypes.Structure):
        _fields_ = [("low", _ctypes.c_ulong), ("high", _ctypes.c_ulong)]

    idle, kernel, user = _FT(), _FT(), _FT()
    try:
        if os.name != 'nt':
            return {"cpu_percent": 0, "memory_total_gb": 0, "memory_used_gb": 0, "memory_percent": 0}
        _ctypes.windll.kernel32.GetSystemTimes(
            _ctypes.byref(idle), _ctypes.byref(kernel), _ctypes.byref(user))
    except Exception:
        return 0.0

    def v(t):
        return (t.high << 32) | t.low

    now = (v(idle), v(kernel), v(user))
    if _cpu_last is None:
        _cpu_last = now
        return 0.0
    di = now[0] - _cpu_last[0]
    dk = now[1] - _cpu_last[1]
    du = now[2] - _cpu_last[2]
    _cpu_last = now
    total = dk + du
    if total <= 0:
        return 0.0
    return round(max(0.0, min(100.0, (total - di) * 100.0 / total)), 1)


@app.route("/api/system", methods=["GET"])
def get_system_info():
    """系统状态：CPU/内存/磁盘/Python/运行时长，供系统状态页使用"""
    try:
        mem = _MEMORYSTATUSEX()
        mem.dwLength = _ctypes.sizeof(_MEMORYSTATUSEX)
        if os.name != 'nt':
            return {"cpu_percent": 0, "memory_total_gb": 0, "memory_used_gb": 0, "memory_percent": 0}
        _ctypes.windll.kernel32.GlobalMemoryStatusEx(_ctypes.byref(mem))
        mem_total = round(mem.ullTotalPhys / 1024**3, 1)
        mem_used = round((mem.ullTotalPhys - mem.ullAvailPhys) / 1024**3, 1)
        mem_percent = mem.dwMemoryLoad
    except Exception:
        mem_total = mem_used = mem_percent = 0

    try:
        total, used, free = _shutil.disk_usage(str(BASE_DIR.anchor or "C:\\"))
        disk_total = round(total / 1024**3, 0)
        disk_used = round(used / 1024**3, 0)
        disk_percent = round(used * 100.0 / total, 1) if total else 0
    except Exception:
        disk_total = disk_used = disk_percent = 0

    uptime = int(time.time() - _SERVICE_START)
    cpu_model = "CPU"
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as _k:
            cpu_model = str(winreg.QueryValueEx(_k, "ProcessorNameString")[0]).strip()
    except Exception:
        try:
            cpu_model = _platform.processor() or "CPU"
        except Exception:
            cpu_model = "CPU"
    try:
        acc_data = load_config()
        acc_count = len(acc_data.get("accounts", []))
    except Exception:
        acc_count = 0

    return jsonify({
        "success": True,
        "cpu_percent": _cpu_percent(),
        "cpu_model": cpu_model,
        "mem_total": mem_total, "mem_used": mem_used, "mem_percent": mem_percent,
        "disk_total": disk_total, "disk_used": disk_used, "disk_percent": disk_percent,
        "python_version": _sys_version(),
        "platform": _platform.platform(),
        "machine": _platform.machine(),
        "uptime_seconds": uptime,
        "account_count": acc_count,
    })


def _sys_version():
    import sys
    return ".".join(str(x) for x in sys.version_info[:3])


@app.route("/api/remote-url", methods=["GET"])
def get_remote_url():
    """获取cpolar远程访问地址（从Web界面HTML解析，API返回空时备用）"""
    import urllib.request
    import re

    # 方案1：尝试cpolar本地API（4040和4042端口）
    for port in [4040, 4042]:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/tunnels")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            tunnels = data.get("tunnels", [])
            urls = [t.get("public_url", "") for t in tunnels if t.get("public_url")]
            https_urls = [u for u in urls if u.startswith("https")]
            remote_url = https_urls[0] if https_urls else (urls[0] if urls else "")
            if remote_url:
                return jsonify({"success": True, "remote_url": remote_url, "all_urls": urls})
        except Exception:
            continue

    # 方案2：从cpolar Web界面HTML解析地址（API返回空时的备用方案）
    for port in [4042, 4040]:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{port}/")
            with urllib.request.urlopen(req, timeout=3) as resp:
                html = resp.read().decode("utf-8", errors="replace")
            # 匹配 cpolar.top 地址（去掉转义反斜杠）
            matches = re.findall(r'https?://[a-zA-Z0-9.-]+\.cpolar\.[a-zA-Z0-9.-]+', html)
            if matches:
                # 清理末尾的转义字符
                cleaned = [m.rstrip('\\/').strip() for m in matches]
                https_matches = [m for m in cleaned if m.startswith("https")]
                remote_url = https_matches[0] if https_matches else cleaned[0]
                all_urls = list(set(cleaned))
                return jsonify({"success": True, "remote_url": remote_url, "all_urls": all_urls})
        except Exception:
            continue

    # 方案3：从cpolar日志文件解析
    try:
        log_path = BASE_DIR / "logs" / "cpolar.log"
        if log_path.exists():
            content = log_path.read_text(encoding="utf-8", errors="replace")
            matches = re.findall(r'https?://[^\s]+\.cpolar\.[^\s]+', content)
            if matches:
                https_matches = [m for m in matches if m.startswith("https")]
                remote_url = https_matches[-1] if https_matches else matches[-1]
                return jsonify({"success": True, "remote_url": remote_url, "all_urls": list(set(matches))})
    except Exception:
        pass

    return jsonify({"success": False, "error": "远程访问未启动或地址尚未获取"})


@app.route("/api/screenshot", methods=["GET"])
def get_live_screenshot():
    """获取当前活跃浏览器的实时截图（用于网页实时画面）"""
    config = load_config()
    if not config.get("live_view_enabled", True):
        return jsonify({"success": False, "error": "实时画面已关闭"}), 403
    from douyin_bot import get_active_screenshot
    img = get_active_screenshot()
    if img is None:
        return jsonify({"success": False, "error": "没有活跃的浏览器画面"}), 404
    from flask import Response
    return Response(img, mimetype="image/jpeg")


# ===== API: 远程控制浏览器（用于手机远程登录）=====
@app.route("/api/remote/click", methods=["POST"])
def remote_click():
    data = request.get_json() or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"success": False, "error": "missing text"}), 400
    from douyin_bot import DouyinBot
    for bot in DouyinBot._active_bots:
        try:
            if bot._page and not bot._page.is_closed():
                with bot._cmd_lock:
                    bot._cmd_queue.append({"action": "click", "text": text})
                return jsonify({"success": True, "message": "queued click: " + text})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500
    return jsonify({"success": False, "error": "no active browser"}), 404


@app.route("/api/remote/type", methods=["POST"])
def remote_type():
    data = request.get_json() or {}
    text = data.get("text", "")
    if not text:
        return jsonify({"success": False, "error": "missing text"}), 400
    from douyin_bot import DouyinBot
    for bot in DouyinBot._active_bots:
        try:
            if bot._page and not bot._page.is_closed():
                with bot._cmd_lock:
                    bot._cmd_queue.append({"action": "input", "text": text})
                return jsonify({"success": True, "message": "queued input"})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500
    return jsonify({"success": False, "error": "no active browser"}), 404


@app.route("/api/remote/press", methods=["POST"])
def remote_press():
    data = request.get_json() or {}
    key = data.get("key", "Enter")
    from douyin_bot import DouyinBot
    for bot in DouyinBot._active_bots:
        try:
            if bot._page and not bot._page.is_closed():
                with bot._cmd_lock:
                    bot._cmd_queue.append({"action": "press", "key": key})
                return jsonify({"success": True, "message": "queued key: " + key})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500
    return jsonify({"success": False, "error": "no active browser"}), 404


@app.route("/api/browser/close-all", methods=["POST"])
def browser_close_all():
    """关闭所有活跃浏览器（取消当前任务），先关闭浏览器再切回管理面板"""
    from douyin_bot import DouyinBot
    import subprocess
    import time
    closed = 0
    pids_to_kill = []
    bots_to_complete = []
    # 第一步：关闭所有浏览器
    for bot in DouyinBot._active_bots[:]:
        try:
            if hasattr(bot, '_browser_pid') and bot._browser_pid:
                pids_to_kill.append(bot._browser_pid)
        except Exception:
            pass
        try:
            if bot._browser:
                bot._browser.close()
        except Exception:
            pass
        # 只要在活跃列表里就算一个（不管browser对象是否为None）
        closed += 1
        bots_to_complete.append(bot)
    DouyinBot._active_bots.clear()
    # 强制杀残留进程（/T杀进程树）
    for pid in pids_to_kill:
        try:
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)], capture_output=True, timeout=5)
        except Exception:
            pass
    # 额外兜底：杀掉标题含"抖音聊天"或"douyin.com/chat"的Edge窗口
    fallback_killed = 0
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kill_pids = set()
        def enum_cb(hwnd, _):
            if user32.IsWindowVisible(hwnd):
                length = user32.GetWindowTextLengthW(hwnd)
                if length > 0:
                    buf = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, buf, length + 1)
                    title = buf.value
                    if '抖音聊天' in title or 'douyin.com/chat' in title:
                        pid = wintypes.DWORD()
                        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                        kill_pids.add(pid.value)
            return True
        WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
        for pid in kill_pids:
            if pid not in pids_to_kill:
                r = subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)], capture_output=True, timeout=5)
                if r.returncode == 0:
                    fallback_killed += 1
    except Exception:
        pass
    closed += fallback_killed
    # 第二步：等待浏览器关闭后，切回管理面板
    time.sleep(0.8)
    # 即使bots_to_complete为空，也要尝试切回管理面板
    if bots_to_complete:
        for bot in bots_to_complete:
            try:
                bot.task_complete()
            except Exception:
                pass
    else:
        # 兜底：找到管理面板窗口并激活（Alt键技巧绕过前台限制）
        try:
            import ctypes
            from ctypes import wintypes
            import time as _time
            user32 = ctypes.windll.user32
            target_hwnd = None
            def find_panel(hwnd, _):
                nonlocal target_hwnd
                if user32.IsWindowVisible(hwnd):
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buf = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buf, length + 1)
                        if "抖音自动续火花" in buf.value:
                            target_hwnd = hwnd
                            return False
                return True
            WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
            user32.EnumWindows(WNDENUMPROC(find_panel), 0)
            if target_hwnd:
                user32.keybd_event(0x12, 0, 0, 0)
                _time.sleep(0.05)
                user32.ShowWindow(target_hwnd, 3)  # SW_SHOWMAXIMIZED
                user32.SetForegroundWindow(target_hwnd)
                _time.sleep(0.05)
                user32.keybd_event(0x12, 0, 2, 0)
        except Exception:
            pass
    logger.info(f"已关闭 {closed} 个浏览器（活跃{closed-fallback_killed}+兜底{fallback_killed}）")
    return jsonify({"success": True, "closed": closed})


@app.route("/api/spark/refresh-status", methods=["GET"])
def spark_refresh_status():
    """查询刷新火花任务是否正在运行"""
    global _spark_refresh_running
    return jsonify({"running": _spark_refresh_running})


@app.route("/api/remote/page_state", methods=["GET"])
def remote_page_state():
    """获取当前页面状态，检测是否有登录方式选择、验证码输入框等"""
    from douyin_bot import DouyinBot, LOGIN_MARKERS, CONVERSATION_ITEM_SELECTOR
    state = {
        "has_active_browser": False,
        "url": "",
        "show_login_options": False,
        "has_qr_login": False,
        "has_sms_login": False,
        "has_password_login": False,
        "has_code_input": False,
        "has_password_input": False,
        "has_any_input": False,
        "is_logged_in": False,
        "page_title": "",
    }
    for bot in DouyinBot._active_bots:
        try:
            if bot._page and not bot._page.is_closed():
                state["has_active_browser"] = True
                state["url"] = bot._page.url
                state["page_title"] = bot._page.title()
                # 获取完整页面文字（遍历shadow DOM和iframe）
                body_text = ""
                try:
                    body_text = bot._page.evaluate("""() => {
                        let text = '';
                        function walk(node) {
                            if (node.nodeType === 3) text += node.textContent + ' ';
                            if (node.nodeType === 1) {
                                if (node.shadowRoot) node.shadowRoot.childNodes.forEach(walk);
                                // 遍历iframe
                                if (node.tagName === 'IFRAME') {
                                    try {
                                        if (node.contentDocument) walk(node.contentDocument.body);
                                    } catch(e) {}
                                }
                                node.childNodes.forEach(walk);
                            }
                        }
                        walk(document);
                        return text;
                    }""")
                except Exception:
                    pass
                # 兜底：普通body文字
                if not body_text:
                    try:
                        body_text = bot._page.locator("body").inner_text(timeout=3000)
                    except Exception:
                        body_text = ""
                if not body_text:
                    body_text = ""
                state["body_text"] = body_text[:2000]
                # 检测登录方式选项
                state["has_qr_login"] = any(k in body_text for k in ["扫码登录", "二维码登录", "扫码", "QR码登录"])
                state["has_sms_login"] = any(k in body_text for k in ["验证码登录", "短信登录", "手机验证码", "短信验证"])
                state["has_password_login"] = any(k in body_text for k in ["密码登录", "账号密码", "密码"])
                # 检测二次认证（验证登录密码/验证弹窗）
                state["has_verify_popup"] = any(k in body_text for k in ["验证登录密码", "验证", "确认登录", "安全验证"])
                state["has_verify_button"] = any(k in body_text for k in ["验证", "确认", "下一步"])
                state["show_login_options"] = state["has_qr_login"] or state["has_sms_login"] or state["has_password_login"] or state["has_verify_popup"]
                # 检测各种输入框
                all_inputs = bot._page.locator("input").all()
                for inp in all_inputs:
                    try:
                        inp_type = inp.get_attribute("type") or "text"
                        placeholder = inp.get_attribute("placeholder") or ""
                        if inp_type == "password":
                            state["has_password_input"] = True
                        if any(k in placeholder for k in ["验证码", "code", "验证", "短信", "手机"]) or inp_type == "tel":
                            state["has_code_input"] = True
                        state["has_any_input"] = True
                    except Exception:
                        pass
                # 如果有输入框但没检测到登录方式，也显示面板
                if state["has_code_input"] or state["has_password_input"]:
                    state["show_login_options"] = True
                # 检测是否已登录（有会话列表）
                state["is_logged_in"] = bot._page.locator(CONVERSATION_ITEM_SELECTOR).count() > 0
                break
        except Exception:
            pass
    return jsonify(state)


# ===== API: 定时设置 =====
@app.route("/api/schedule", methods=["GET"])
def get_schedule():
    config = load_config()
    sched = config.get("schedule", {})
    return jsonify({
        "enabled": sched.get("enabled", True),
        "hour": sched.get("hour", 0),
        "minute": sched.get("minute", 30),
    })


@app.route("/api/schedule", methods=["POST"])
def update_schedule():
    data = request.get_json() or {}
    config = load_config()
    if "schedule" not in config:
        config["schedule"] = {}
    if "enabled" in data:
        config["schedule"]["enabled"] = data["enabled"]
    if "hour" in data:
        config["schedule"]["hour"] = int(data["hour"])
    if "minute" in data:
        config["schedule"]["minute"] = int(data["minute"])
    save_config(config)
    scheduler.reschedule(
        config["schedule"].get("hour", 0),
        config["schedule"].get("minute", 30),
        config["schedule"].get("enabled", True),
    )
    return jsonify({"success": True, "schedule": config["schedule"]})


@app.route("/api/accounts/<int:idx>/schedule", methods=["POST"])
def update_account_schedule(idx):
    data = request.get_json() or {}
    config = load_config()
    accounts = config.get("accounts", [])
    if idx >= len(accounts):
        return jsonify({"success": False, "error": "账号不存在"}), 404
    if "schedule" not in accounts[idx]:
        accounts[idx]["schedule"] = {"enabled": False, "hour": 0, "minute": 30}
    if "enabled" in data:
        accounts[idx]["schedule"]["enabled"] = data["enabled"]
    if "hour" in data:
        accounts[idx]["schedule"]["hour"] = int(data["hour"])
    if "minute" in data:
        accounts[idx]["schedule"]["minute"] = int(data["minute"])
    save_config(config)
    scheduler.reschedule_account(
        idx,
        accounts[idx]["schedule"].get("hour", 0),
        accounts[idx]["schedule"].get("minute", 30),
        accounts[idx]["schedule"].get("enabled", False),
    )
    return jsonify({"success": True, "schedule": accounts[idx]["schedule"]})


@app.route("/api/logs", methods=["GET"])
def get_logs():
    """获取最近的日志"""
    log_file = LOG_DIR / "app.log"
    if not log_file.exists():
        return jsonify({"logs": ""})
    try:
        with open(log_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        # 返回最后 200 行
        return jsonify({"logs": "".join(lines[-200:])})
    except Exception as e:
        return jsonify({"logs": f"读取日志失败: {e}"})


# ===== API: 截图列表 =====
@app.route("/api/screenshots", methods=["GET"])
def list_screenshots():
    shot_dir = BASE_DIR / "screenshots"
    files = sorted(shot_dir.glob("*.png"), key=lambda f: f.stat().st_mtime, reverse=True)
    return jsonify([
        {"name": f.name, "size": f.stat().st_size, "mtime": datetime.fromtimestamp(f.stat().st_mtime).isoformat()}
        for f in files[:30]
    ])


@app.route("/screenshots/<filename>")
def get_screenshot(filename):
    """提供截图访问"""
    from flask import send_from_directory
    return send_from_directory(BASE_DIR / "screenshots", filename)


# ===== API: 清空历史记录 =====
@app.route("/api/history/clear", methods=["POST"])
def clear_history():
    """清空所有执行历史记录、截图缓存、日志缓存"""
    try:
        # 清空历史记录
        history_file = LOG_DIR / "history.json"
        if history_file.exists():
            history_file.unlink()
        scheduler._history = []
        scheduler._last_run = None

        # 清空截图缓存
        shot_dir = BASE_DIR / "screenshots"
        if shot_dir.exists():
            for f in shot_dir.glob("*.png"):
                try: f.unlink()
                except Exception: pass

        # 注意：不清空 app.log —— RotatingFileHandler 仍持有该文件句柄，
        # Windows 下截断会导致后续日志写入空洞/异常。日志按大小自动轮转。

        # 清理 __pycache__
        for pyc in BASE_DIR.rglob("__pycache__"):
            try:
                import shutil
                shutil.rmtree(pyc, ignore_errors=True)
            except Exception: pass

        logger.info("历史记录、截图缓存、日志缓存已清空")
        return jsonify({"success": True, "message": "历史记录、截图缓存、日志缓存已清空"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ===== API: 在线更新 =====
import zipfile, shutil, tempfile

def _apply_update(zip_path):
    """核心更新逻辑：解压zip → 保留用户数据 → 生成更新脚本 → 重启服务"""
    try:
        update_dir = BASE_DIR.parent / "douyin_spark_update_temp"
        if update_dir.exists():
            shutil.rmtree(update_dir, ignore_errors=True)
        update_dir.mkdir(parents=True)

        # 解压更新包
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(update_dir)

        # 如果解压后只有一个子目录，进入它
        subdirs = [d for d in update_dir.iterdir() if d.is_dir()]
        if len(subdirs) == 1 and not any(update_dir.glob("*.py")):
            update_dir = subdirs[0]

        # 保留用户数据：从当前目录复制到更新目录
        user_data = ["config.json", "stats.json"]
        for f in user_data:
            src = BASE_DIR / f
            dst = update_dir / f
            if src.exists():
                shutil.copy2(src, dst)

        # 保留storage目录（登录状态）
        src_storage = BASE_DIR / "storage"
        dst_storage = update_dir / "storage"
        if src_storage.exists():
            if dst_storage.exists():
                shutil.rmtree(dst_storage)
            shutil.copytree(src_storage, dst_storage)

        # 保留logs目录
        src_logs = BASE_DIR / "logs"
        dst_logs = update_dir / "logs"
        if src_logs.exists() and not dst_logs.exists():
            shutil.copytree(src_logs, dst_logs)

        # 生成更新脚本（跨平台）
        import sys, os
        python_exe = sys.executable
        if os.name == "nt":
            bat_path = BASE_DIR.parent / "douyin_spark_do_update.bat"
            script = f"""@echo off
chcp 65001 >nul
timeout /t 3 /nobreak >nul
echo 正在停止服务...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :5000 ^| findstr LISTENING') do taskkill /f /pid %%a >nul 2>&1
timeout /t 2 /nobreak >nul
echo 正在更新文件（保留用户数据）...
robocopy "{update_dir}" "{BASE_DIR}" /E /IS /IT /NFL /NDL /NJH /NJS /NP /XF config.json stats.json /XD storage logs screenshots
echo 正在启动服务...
cd /d "{BASE_DIR}"
start "" "{python_exe}" app.py
timeout /t 2 /nobreak >nul
rmdir /s /q "{update_dir}"
del "%~f0"
"""
            bat_path.write_text(script, encoding="utf-8")
            subprocess.Popen(["cmd", "/c", str(bat_path)],
                creationflags=0x08000000 if os.name == 'nt' else 0)
        else:
            sh_path = BASE_DIR.parent / "douyin_spark_do_update.sh"
            script = f"""#!/bin/bash
sleep 3
cp -r "{update_dir}"/* "{BASE_DIR}/"
systemctl restart spark
rm -rf "{update_dir}"
rm -f "$0"
"""
            sh_path.write_text(script)
            sh_path.chmod(0o755)
            subprocess.Popen(["/bin/bash", str(sh_path)])

        logger.info("更新包已接收，服务将在3秒后重启完成更新")
        return True, "更新包已接收，服务即将重启，约10秒后刷新页面"
    except Exception as e:
        logger.error(f"更新失败: {e}", exc_info=True)
        return False, f"更新失败: {e}"


@app.route("/api/update/upload", methods=["POST"])
def update_upload():
    """上传更新包进行更新"""
    if 'file' not in request.files:
        return jsonify({"success": False, "error": "请选择更新包文件"}), 400
    f = request.files['file']
    if not f.filename.endswith('.zip'):
        return jsonify({"success": False, "error": "请上传ZIP格式的更新包"}), 400

    tmp_zip = BASE_DIR.parent / "douyin_spark_update.zip"
    f.save(tmp_zip)
    ok, msg = _apply_update(tmp_zip)
    try: tmp_zip.unlink()
    except: pass
    return jsonify({"success": ok, "message": msg})


@app.route("/api/update/url", methods=["POST"])
def update_url():
    """从URL下载更新包进行更新"""
    data = request.get_json(silent=True) or {}
    url = data.get("url", "").strip()
    if not url:
        return jsonify({"success": False, "error": "请提供更新包下载链接"}), 400

    try:
        import urllib.request
        tmp_zip = BASE_DIR.parent / "douyin_spark_update.zip"
        urllib.request.urlretrieve(url, tmp_zip)
        ok, msg = _apply_update(tmp_zip)
        try: tmp_zip.unlink()
        except: pass
        return jsonify({"success": ok, "message": msg})
    except Exception as e:
        return jsonify({"success": False, "error": f"下载失败: {e}"}), 500


@app.route("/api/update/check", methods=["GET"])
def update_check():
    """检查更新（从GitHub获取最新版本信息）"""
    config = load_config()
    current = APP_VERSION
    default_update_sources = [
        "https://cdn.jsdelivr.net/gh/huiyao0908/douyin-spark-updates@main/version.json",
        "https://raw.githubusercontent.com/huiyao0908/douyin-spark-updates/main/version.json",
        "https://ghproxy.net/https://raw.githubusercontent.com/huiyao0908/douyin-spark-updates/main/version.json",
    ]
    update_source = config.get("update_source")
    sources = [update_source] if update_source else default_update_sources

    try:
        import urllib.request
        import time
        remote = None
        for src in sources:
            try:
                sep = "&" if "?" in src else "?"
                url_with_cache = f"{src}{sep}_t={int(time.time())}"
                req = urllib.request.Request(url_with_cache, headers={"User-Agent": "douyin-spark", "Cache-Control": "no-cache", "Pragma": "no-cache"})
                with urllib.request.urlopen(req, timeout=15) as resp:
                    remote = json.loads(resp.read().decode("utf-8"))
                break
            except Exception:
                continue
        if remote is None:
            raise Exception("所有源均无法连接")
        latest = remote.get("latest_version", current)
        download_url = remote.get("download_url", "")
        changelog = remote.get("changelog", {})
        has_update = latest != current
        return jsonify({
            "success": True,
            "current_version": current,
            "latest_version": latest,
            "has_update": has_update,
            "download_url": download_url,
            "changelog": changelog
        })
    except Exception as e:
        # 网络失败时返回本地配置
        latest = config.get("latest_version", current)
        return jsonify({
            "success": False,
            "current_version": current,
            "latest_version": latest,
            "has_update": False,
            "download_url": "",
            "changelog": {},
            "error": f"检查更新失败: {e}"
        })


# ===== 更新下载管理 =====
_update_download_state = {
    "downloading": False,
    "progress": 0,
    "speed": 0,
    "eta": 0,
    "done": False,
    "canceled": False,
    "error": "",
    "file_path": "",
    "total_size": 0,
    "downloaded": 0
}

def _do_update_download(url, save_path):
    """后台线程：下载更新包并报告进度"""
    import urllib.request, time, threading
    state = _update_download_state
    state.update({"downloading": True, "progress": 0, "speed": 0, "eta": 0,
                  "done": False, "canceled": False, "error": "", "downloaded": 0,
                  "total_size": 0, "file_path": ""})
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            state["total_size"] = total
            downloaded = 0
            chunk_size = 65536
            start_time = time.time()
            last_time = start_time
            last_downloaded = 0
            with open(save_path, "wb") as f:
                while True:
                    if state["canceled"]:
                        f.close()
                        import os as _os
                        if _os.path.exists(save_path): _os.remove(save_path)
                        state.update({"downloading": False, "canceled": True})
                        return
                    chunk = resp.read(chunk_size)
                    if not chunk: break
                    f.write(chunk)
                    downloaded += len(chunk)
                    state["downloaded"] = downloaded
                    now = time.time()
                    if now - last_time >= 0.3:
                        speed = (downloaded - last_downloaded) / (now - last_time)
                        state["speed"] = round(speed, 1)
                        if total > 0:
                            state["progress"] = round(downloaded / total * 100, 1)
                            remaining = (total - downloaded) / speed if speed > 0 else 0
                            state["eta"] = round(remaining)
                        last_time = now
                        last_downloaded = downloaded
            state["progress"] = 100
            state["done"] = True
            state["file_path"] = save_path
            state["downloading"] = False
            logger.info(f"更新包下载完成: {save_path}")
    except Exception as e:
        state["error"] = str(e)
        state["downloading"] = False
        logger.error(f"更新包下载失败: {e}")

@app.route("/api/update/download", methods=["POST"])
def update_download():
    """启动后台下载更新包"""
    if _update_download_state["downloading"]:
        return jsonify({"success": False, "error": "已有下载任务进行中"})
    data = request.get_json() or {}
    url = data.get("url", "")
    if not url:
        return jsonify({"success": False, "error": "缺少下载链接"})
    import tempfile, threading
    save_path = os.path.join(tempfile.gettempdir(), "douyin_spark_update.zip")
    t = threading.Thread(target=_do_update_download, args=(url, save_path), daemon=True)
    t.start()
    return jsonify({"success": True, "message": "开始下载"})

@app.route("/api/update/progress", methods=["GET"])
def update_progress():
    """获取下载进度"""
    state = _update_download_state
    # 计算与前端匹配的status字段
    if state["error"]:
        status = "error"
    elif state["canceled"]:
        status = "cancelled"
    elif state["done"]:
        status = "done"
    elif state["downloading"]:
        status = "downloading"
    else:
        status = "idle"
    return jsonify({
        "success": True,
        "status": status,
        "downloading": state["downloading"],
        "progress": state["progress"],
        "speed": state["speed"],
        "eta": state["eta"],
        "done": state["done"],
        "canceled": state["canceled"],
        "error": state["error"],
        "total_size": state["total_size"],
        "downloaded": state["downloaded"]
    })

@app.route("/api/update/cancel", methods=["POST"])
def update_cancel():
    """取消下载"""
    _update_download_state["canceled"] = True
    return jsonify({"success": True, "message": "正在取消下载"})

@app.route("/api/update/apply", methods=["POST"])
def update_apply():
    """安装已下载的更新包（保留用户数据）"""
    import zipfile, tempfile, shutil, threading, time, subprocess, sys
    state = _update_download_state
    if not state["done"] or not state["file_path"]:
        return jsonify({"success": False, "error": "更新包尚未下载完成"})
    zip_path = state["file_path"]
    if not os.path.exists(zip_path):
        return jsonify({"success": False, "error": "更新包文件不存在"})

    project_dir = str(BASE_DIR)
    keep_items = {"config.json", "stats.json", "storage", "logs", "screenshots"}

    def _do_apply():
        try:
            time.sleep(1)
            with zipfile.ZipFile(zip_path) as zf:
                for member in zf.namelist():
                    if member.endswith("/"): continue
                    top = member.replace("\\", "/").split("/")[0]
                    if top in keep_items: continue
                    target = os.path.join(project_dir, member.replace("/", os.sep))
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with zf.open(member) as src, open(target, "wb") as dst:
                        shutil.copyfileobj(src, dst)
            logger.info("更新安装完成，准备重启服务")
            # 重启服务
            subprocess.Popen([sys.executable, os.path.join(project_dir, "app.py")],
                           cwd=project_dir, creationflags=0x08000000 if os.name == 'nt' else 0)
            time.sleep(1)
            os._exit(0)
        except Exception as e:
            logger.error(f"更新安装失败: {e}")

    threading.Thread(target=_do_apply, daemon=True).start()
    return jsonify({"success": True, "message": "更新安装中，服务将在约10秒后自动重启"})


# ===== API: 一键黑屏/亮屏 =====
@app.route("/api/monitor/off", methods=["POST"])
def monitor_off():
    config = load_config()
    if not config.get("monitor_control_enabled", False):
        return jsonify({"success": False, "error": "黑屏功能未启用"}), 403
    try:
        import subprocess, sys, tempfile
        stop_file = os.path.join(tempfile.gettempdir(), "douyin_black_screen.stop")
        if os.path.exists(stop_file): os.remove(stop_file)
        script = r"C:\Users\admin\Desktop\黑屏工具.py"
        if not os.path.exists(script): script = str(BASE_DIR / "黑屏工具.py")
        subprocess.Popen([sys.executable, script], creationflags=0x08000000 if os.name == 'nt' else 0)
        logger.info("一键黑屏已启动")
        return jsonify({"success": True, "message": "屏幕已关闭，连续按3次ESC或点击亮屏恢复"})
    except Exception as e:
        logger.error(f"黑屏失败: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/monitor/on", methods=["POST"])
def monitor_on():
    config = load_config()
    if not config.get("monitor_control_enabled", False):
        return jsonify({"success": False, "error": "亮屏功能未启用"}), 403
    try:
        import ctypes, subprocess, tempfile, time
        stop_file = os.path.join(tempfile.gettempdir(), "douyin_black_screen.stop")
        with open(stop_file, "w") as f: f.write("stop")
        pid_file = os.path.join(tempfile.gettempdir(), "douyin_black_screen.pid")
        if os.path.exists(pid_file):
            try:
                with open(pid_file) as f: pid = int(f.read().strip())
                subprocess.run(["taskkill", "/f", "/pid", str(pid)], capture_output=True)
            except: pass
        time.sleep(0.6)
        try:
            result = subprocess.run(["wmic","process","where","commandline like '%黑屏工具%'","get","processid"],
                                    capture_output=True, text=True, timeout=5)
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if line.isdigit(): subprocess.run(["taskkill","/f","/pid",line], capture_output=True)
        except: pass
        res = ctypes.c_void_p()
        ctypes.windll.user32.SendMessageTimeoutW(0xFFFF,0x0112,0xF170,-1,0x0002,2000,ctypes.byref(res))
        time.sleep(0.3)
        ctypes.windll.user32.mouse_event(0x0001,10,10,0,0)
        try:
            if os.path.exists(stop_file): os.remove(stop_file)
        except: pass
        logger.info("一键亮屏已执行")
        return jsonify({"success": True, "message": "屏幕已亮起"})
    except Exception as e:
        logger.error(f"亮屏失败: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


# ===== 启动 =====
if __name__ == "__main__":
    # 启动时清理旧截图
    cleanup_screenshots(keep_last=20)
    # 启动定时调度器
    scheduler.start()
    logger.info("抖音自动续火花服务启动中...")
    logger.info("本机访问: http://127.0.0.1:5000")
    logger.info("手机访问: http://192.168.0.115:5000 (需同一WiFi)")
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False, threaded=True)
