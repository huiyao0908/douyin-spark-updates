@echo off
chcp 65001 >nul
:: 开机自启动脚本 - 启动QQ机器人+抖音续火花
:: 此文件被开机启动VBS调用

:: 启动QQ机器人
start "" /min "C:\milkbot\start_bot.bat"
timeout /t 3 /nobreak >nul

:: 启动NapCat
schtasks /run /tn "NapCatLauncher" >nul 2>&1

:: 启动抖音续火花
cd /d "D:\抖音续火花"
start "" /min "D:\抖音续火花\启动服务.bat"
timeout /t 8 /nobreak >nul

:: 打开管理面板
start "" "http://127.0.0.1:5000/"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:6099/webui?token=4c4fd725de88"
