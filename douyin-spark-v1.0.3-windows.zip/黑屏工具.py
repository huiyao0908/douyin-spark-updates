# -*- coding: utf-8 -*-
"""
一键黑屏（本机自用，不进发布包）
- 真正关闭显示器背光（SC_MONITORPOWER = OFF），不是用黑窗口遮挡
- 1.5 秒内连续按 3 次 ESC 自动退出并亮屏
- 检测到鼠标移动 / 按键会立即重新关屏，每 2 秒主动关屏，对抗设备唤醒
- 收到停止标记文件、或已有一个黑屏进程在跑时自动退出（单实例）
说明：Windows 下物理键鼠动作点亮屏幕属系统行为，若想完全不被唤醒，请拔掉鼠标键盘。
"""
import ctypes
import time
import os
import tempfile

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

HWND_BROADCAST = 0xFFFF
WM_SYSCOMMAND = 0x0112
SC_MONITORPOWER = 0xF170
MONITOR_OFF = 2
MONITOR_ON = -1
VK_ESCAPE = 0x1B


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


TEMP = tempfile.gettempdir()
PID_FILE = os.path.join(TEMP, "douyin_black_screen.pid")
STOP_FILE = os.path.join(TEMP, "douyin_black_screen.stop")

# 视为“活动”的按键：鼠标左/右/中键、空格、回车、Tab、方向键
ACTIVITY_VKS = (0x01, 0x02, 0x04, 0x20, 0x0D, 0x09, 0x25, 0x26, 0x27, 0x28)


def monitor(state):
    res = ctypes.c_void_p()
    try:
        user32.SendMessageTimeoutW(
            HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, state,
            0x0002, 1000, ctypes.byref(res)
        )
    except Exception:
        pass


def get_cursor():
    pt = POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return (pt.x, pt.y)


def pressed(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


def already_running():
    """单实例：PID 文件指向的进程若仍存活，则新实例直接退出。"""
    if not os.path.exists(PID_FILE):
        return False
    try:
        old = int(open(PID_FILE).read().strip())
    except Exception:
        return False
    if old == os.getpid():
        return False
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, old)
    if h:
        kernel32.CloseHandle(h)
        return True
    return False


def cleanup_files():
    for f in (PID_FILE, STOP_FILE):
        try:
            if os.path.exists(f):
                os.remove(f)
        except Exception:
            pass


def main():
    if os.path.exists(STOP_FILE):
        try:
            os.remove(STOP_FILE)
        except Exception:
            pass
    if already_running():
        return

    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    last_pos = get_cursor()
    last_forced = time.time()
    esc_count = 0
    last_esc = 0.0

    monitor(MONITOR_OFF)

    try:
        while True:
            # 收到网页/脚本亮屏指令
            if os.path.exists(STOP_FILE):
                try:
                    os.remove(STOP_FILE)
                except Exception:
                    pass
                break

            now = time.time()

            # 三击 ESC 退出
            if pressed(VK_ESCAPE):
                esc_count = esc_count + 1 if now - last_esc < 1.5 else 1
                last_esc = now
                if esc_count >= 3:
                    break
                time.sleep(0.18)
                continue

            cur = get_cursor()
            moved = abs(cur[0] - last_pos[0]) > 2 or abs(cur[1] - last_pos[1]) > 2
            key_hit = any(pressed(v) for v in ACTIVITY_VKS)

            need_off = False
            if moved or key_hit:
                need_off = True          # 一有活动立刻再关，把闪烁压到最短
            elif now - last_forced > 2.0:
                need_off = True          # 每 2 秒主动关一次，防止被设备唤醒后一直亮

            if need_off:
                monitor(MONITOR_OFF)
                last_forced = now

            last_pos = cur
            time.sleep(0.03)
    except Exception:
        pass
    finally:
        monitor(MONITOR_ON)
        time.sleep(0.2)
        monitor(MONITOR_ON)              # 双保险唤醒
        cleanup_files()


if __name__ == "__main__":
    main()
