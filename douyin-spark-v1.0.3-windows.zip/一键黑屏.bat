﻿@echo off
chcp 65001 >nul
title 一键黑屏
cd /d "%~dp0"
set "PYW=C:\Users\admin\AppData\Local\Programs\Python\Python312\pythonw.exe"
if not exist "%PYW%" set "PYW=pythonw"
start "" /b "%PYW%" "%~dp0黑屏工具.py"
exit
