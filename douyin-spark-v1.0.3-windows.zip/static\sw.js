// 缓存策略：页面(HTML)网络优先，保证每次拿到最新版本；静态资源缓存优先、离线可用
const CACHE_NAME = 'douyin-spark-v2';
const CORE_ASSETS = ['/static/manifest.json'];

self.addEventListener('install', (e) => {
    self.skipWaiting(); // 新版本立即接管，不等旧 SW 释放
    e.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).catch(() => {})
    );
});

self.addEventListener('activate', (e) => {
    e.waitUntil((async () => {
        // 清理所有旧版本缓存
        const keys = await caches.keys();
        await Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)));
        await self.clients.claim();
    })());
});

self.addEventListener('fetch', (e) => {
    const req = e.request;
    if (req.method !== 'GET') return;

    // 导航/页面请求：网络优先 → 回退缓存（保证 HTML 更新能立刻生效）
    if (req.mode === 'navigate') {
        e.respondWith((async () => {
            try {
                const fresh = await fetch(req);
                if (fresh && fresh.status === 200) {
                    const cache = await caches.open(CACHE_NAME);
                    cache.put(req, fresh.clone());
                }
                return fresh;
            } catch (err) {
                const cached = await caches.match(req);
                return cached || caches.match('/');
            }
        })());
        return;
    }

    // 其它静态资源：缓存优先，同时后台更新缓存
    e.respondWith((async () => {
        const cached = await caches.match(req);
        const network = fetch(req).then((res) => {
            if (res && res.status === 200 && res.type === 'basic') {
                const clone = res.clone();
                caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
            }
            return res;
        }).catch(() => cached);
        return cached || network;
    })());
});
