"""
定时任务调度模块
使用 APScheduler 实现每天定时执行续火花任务
"""
import json
import logging
import threading
from datetime import datetime
from pathlib import Path
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from douyin_bot import run_account_task, is_send_cancelled, cancel_send, reset_cancel_send

logger = logging.getLogger("douyin_spark")

BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.json"
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
HISTORY_FILE = LOG_DIR / "history.json"


class SparkScheduler:
    """续火花定时调度器（支持全局定时 + 单账号独立定时）"""

    def __init__(self):
        self.scheduler = BackgroundScheduler(
            timezone="Asia/Shanghai",
            job_defaults={
                "coalesce": True,
                "misfire_grace_time": 3600,
                "max_instances": 1,
            },
        )
        self.job_id = "daily_spark_job"
        self._lock = threading.Lock()
        self._running = False
        self._last_run = None
        self._load_history()

    def _load_config(self) -> dict:
        """加载配置文件"""
        with open(CONFIG_FILE, "r", encoding="utf-8-sig") as f:
            return json.load(f)

    def _load_history(self):
        """加载历史记录"""
        if HISTORY_FILE.exists():
            try:
                with open(HISTORY_FILE, "r", encoding="utf-8-sig") as f:
                    self._history = json.load(f)
            except Exception:
                self._history = []
        else:
            self._history = []

    def _save_history(self, record: dict):
        """保存执行记录"""
        self._history.insert(0, record)
        # 只保留最近 100 条
        self._history = self._history[:100]
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(self._history, f, ensure_ascii=False, indent=2)

    def get_history(self, limit: int = 20) -> list:
        """获取执行历史"""
        return self._history[:limit]

    def get_last_run(self):
        return self._last_run

    def is_running(self) -> bool:
        return self._running

    def cancel(self):
        """取消正在执行的任务（停止所有账号）"""
        cancel_send()
        logger.info("调度器收到取消信号，将停止所有账号")

    def execute_all(self, trigger_type: str = "manual") -> dict:
        """
        执行所有账号的续火花任务
        trigger_type: "scheduled" 或 "manual"
        """
        # 非阻塞抢锁：拿不到说明已有任务在跑，立即拒绝（防重复点击开多套浏览器）
        if not self._lock.acquire(blocking=False):
            logger.warning("任务正在执行中，跳过重复触发")
            return {"error": "任务正在执行中，请稍候"}
        try:
            self._running = True
            reset_cancel_send()  # 重置取消标志，确保新任务不会被之前的取消状态影响
            run_record = {
                "trigger": trigger_type,
                "start_time": datetime.now().isoformat(),
                "end_time": None,
                "accounts": [],
                "total_success": 0,
                "total_failed": 0,
            }

            try:
                config = self._load_config()
                accounts = config.get("accounts", [])
                browser_config = config.get("browser", {})

                logger.info(f"===== 开始执行续火花任务 ({trigger_type}) =====")

                for acc in accounts:
                    if is_send_cancelled():
                        logger.info("任务已取消，跳过剩余账号")
                        remaining = accounts[accounts.index(acc):]
                        for ra in remaining:
                            run_record["accounts"].append({
                                "account": ra.get("name"),
                                "error": "已取消",
                                "success": 0,
                                "failed": len(ra.get("friends", [])),
                            })
                            run_record["total_failed"] += len(ra.get("friends", []))
                        break
                    # 已禁用的账号跳过
                    if not acc.get("enabled", True):
                        logger.info(f"账号 {acc.get('name')} 已禁用，跳过")
                        run_record["accounts"].append({
                            "account": acc.get("name"),
                            "error": "账号已禁用",
                            "success": 0,
                            "failed": 0,
                        })
                        continue
                    # 常驻浏览器账号跳过全部发送（只能单独发送）
                    if acc.get("keep_alive", False):
                        logger.info(f"账号 {acc.get('name')} 开启了浏览器常驻，跳过全部发送（请单独发送）")
                        run_record["accounts"].append({
                            "account": acc.get("name"),
                            "error": "常驻模式需单独发送",
                            "success": 0,
                            "failed": len(acc.get("friends", [])),
                        })
                        run_record["total_failed"] += len(acc.get("friends", []))
                        continue
                    # 有独立定时的账号跳过全局发送
                    if acc.get("schedule", {}).get("enabled", False):
                        logger.info(f"账号 {acc.get('name')} 有独立定时，跳过全局发送")
                        run_record["accounts"].append({
                            "account": acc.get("name"),
                            "error": "独立定时账号",
                            "success": 0,
                            "failed": 0,
                        })
                        continue
                    logger.info(f"--- 处理账号: {acc.get('name')} ---")
                    try:
                        result = run_account_task(acc, browser_config)
                        run_record["accounts"].append(result)
                        run_record["total_success"] += result["success"]
                        run_record["total_failed"] += result["failed"]
                    except Exception as e:
                        logger.error(f"账号 {acc.get('name')} 执行异常: {e}")
                        run_record["accounts"].append({
                            "account": acc.get("name"),
                            "error": str(e),
                            "success": 0,
                            "failed": len(acc.get("friends", [])),
                        })
                        run_record["total_failed"] += len(acc.get("friends", []))

                run_record["end_time"] = datetime.now().isoformat()
                self._last_run = run_record
                self._save_history(run_record)

                logger.info(
                    f"===== 任务完成: 成功 {run_record['total_success']}, "
                    f"失败 {run_record['total_failed']} ====="
                )
                return run_record
            except Exception as e:
                logger.error(f"执行任务异常: {e}")
                run_record["error"] = str(e)
                run_record["end_time"] = datetime.now().isoformat()
                return run_record
            finally:
                self._running = False
        finally:
            self._lock.release()

    def _scheduled_job(self):
        """全局定时任务回调（发送所有未设置独立定时的账号）"""
        logger.info("全局定时任务触发")
        self.execute_all(trigger_type="scheduled")

    def _scheduled_account_job(self, account_idx: int):
        """单账号定时任务回调"""
        logger.info(f"单账号定时任务触发: 账号#{account_idx}")
        try:
            config = self._load_config()
            accounts = config.get("accounts", [])
            if account_idx >= len(accounts):
                logger.warning(f"账号#{account_idx}不存在，跳过定时任务")
                return
            acc = accounts[account_idx]
            if not acc.get("enabled", True):
                logger.info(f"账号 {acc.get('name')} 已禁用，跳过")
                return
            browser_config = config.get("browser", {})
            reset_cancel_send()
            self._running = True
            result = run_account_task(acc, browser_config)
            self._running = False
            run_record = {
                "trigger": "scheduled",
                "start_time": datetime.now().isoformat(),
                "end_time": datetime.now().isoformat(),
                "accounts": [result],
                "total_success": result["success"],
                "total_failed": result["failed"],
            }
            self._last_run = run_record
            self._save_history(run_record)
            logger.info(f"单账号定时完成: {acc.get('name')} 成功{result['success']} 失败{result['failed']}")
        except Exception as e:
            logger.error(f"单账号定时异常: {e}")
            self._running = False

    def start(self):
        """启动调度器（全局 + 单账号定时）"""
        config = self._load_config()
        sched = config.get("schedule", {})
        enabled = sched.get("enabled", True)
        hour = sched.get("hour", 9)
        minute = sched.get("minute", 0)

        if enabled:
            trigger = CronTrigger(hour=hour, minute=minute, timezone="Asia/Shanghai")
            self.scheduler.add_job(
                self._scheduled_job,
                trigger=trigger,
                id=self.job_id,
                replace_existing=True,
            )
            logger.info(f"全局定时已启动，每天 {hour:02d}:{minute:02d} 执行")

        # 启动单账号定时任务
        accounts = config.get("accounts", [])
        for idx, acc in enumerate(accounts):
            acc_sched = acc.get("schedule", {})
            if acc_sched.get("enabled", False):
                acc_hour = acc_sched.get("hour", 9)
                acc_minute = acc_sched.get("minute", 0)
                job_id = f"account_{idx}_schedule"
                trigger = CronTrigger(hour=acc_hour, minute=acc_minute, timezone="Asia/Shanghai")
                self.scheduler.add_job(
                    lambda i=idx: self._scheduled_account_job(i),
                    trigger=trigger,
                    id=job_id,
                    replace_existing=True,
                )
                logger.info(f"账号[{acc.get('name')}]独立定时已启动，每天 {acc_hour:02d}:{acc_minute:02d} 执行")

        if self.scheduler.get_jobs():
            self.scheduler.start()
            logger.info("调度器已启动")

    def reschedule(self, hour: int, minute: int, enabled: bool = True):
        """重新设置全局定时任务时间"""
        if enabled:
            trigger = CronTrigger(hour=hour, minute=minute, timezone="Asia/Shanghai")
            if self.scheduler.running:
                if self.scheduler.get_job(self.job_id):
                    self.scheduler.reschedule_job(self.job_id, trigger=trigger)
                    self.scheduler.resume_job(self.job_id)
                else:
                    self.scheduler.add_job(self._scheduled_job, trigger=trigger, id=self.job_id, replace_existing=True)
            else:
                self.scheduler.add_job(self._scheduled_job, trigger=trigger, id=self.job_id, replace_existing=True)
                self.scheduler.start()
            logger.info(f"全局定时已更新为每天 {hour:02d}:{minute:02d}")
        else:
            if self.scheduler.get_job(self.job_id):
                self.scheduler.pause_job(self.job_id)
            logger.info("全局定时已暂停")

    def reschedule_account(self, account_idx: int, hour: int, minute: int, enabled: bool = True):
        """重新设置单账号定时任务"""
        job_id = f"account_{account_idx}_schedule"
        if enabled:
            trigger = CronTrigger(hour=hour, minute=minute, timezone="Asia/Shanghai")
            if self.scheduler.running:
                if self.scheduler.get_job(job_id):
                    self.scheduler.reschedule_job(job_id, trigger=trigger)
                    self.scheduler.resume_job(job_id)
                else:
                    self.scheduler.add_job(
                        lambda i=account_idx: self._scheduled_account_job(i),
                        trigger=trigger, id=job_id, replace_existing=True
                    )
            else:
                self.scheduler.add_job(
                    lambda i=account_idx: self._scheduled_account_job(i),
                    trigger=trigger, id=job_id, replace_existing=True
                )
                self.scheduler.start()
            logger.info(f"账号#{account_idx}定时已更新为每天 {hour:02d}:{minute:02d}")
        else:
            if self.scheduler.get_job(job_id):
                self.scheduler.remove_job(job_id)
            logger.info(f"账号#{account_idx}定时已关闭")

    def shutdown(self):
        """关闭调度器"""
        if self.scheduler.running:
            self.scheduler.shutdown(wait=False)
            logger.info("调度器已关闭")

    def get_next_run_time(self):
        """获取下次执行时间"""
        if not self.scheduler.running:
            return None
        job = self.scheduler.get_job(self.job_id)
        if job:
            return job.next_run_time.isoformat() if job.next_run_time else None
        return None
